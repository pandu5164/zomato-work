import React, { Component } from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { Link } from 'react-router';
import { Waypoint } from 'react-waypoint';
import LazyLoad from 'react-lazy-load';
import { debounce } from '../utils';
import constants from '../constants'
import Header from '../presentations/Header';
import SvgIcon from '../presentations/SvgIcon';
import SvgLoading from '../presentations/SvgLoading';
import StarIcon from '../assets/images/ic-star-full.svg';
import DefaultProductThumbnailIcon from '../assets/images/food.png';
import { getRestaurantDetail, getRestaurantReviews } from '../actions/restaurantDetailActions';
class RestaurantDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: 'welcome to product detail page',
            restaurentData: {},
            rest_id: null,
            facets:[{id:0,value:'Highlights',isSelected:true},{id:1,value:'Reviews',isSelected:false}],
            selectedView: 'Highlights'
        };
        this.renderReviews = this.renderReviews.bind(this);
        this.setFacet = this.setFacet.bind(this);
        this.listPaneDidMount = this.listPaneDidMount.bind(this);
        this.handleListScroll = this.handleListScroll.bind(this);
        this.fetchMoreReviews = this.fetchMoreReviews.bind(this);
    }
    componentDidMount() {
        if (this.props.params.id) {
            console.log(this.props.params.id);
            this.setState({ rest_id: this.props.params.id });
            this.props.dispatch(getRestaurantDetail(this.props.params.id));
        }
    }
    componentWillUnmount() {
        console.log('Detail page unmounted');
    }
    componentWillReceiveProps(nextProps) {
        if (this.props.restaurentDetailApis.gettingRestaurentDetails && nextProps.restaurentDetailApis.gettingRestaurentDetailsSuccess && nextProps.restaurentDetailApis.restaurentData) {
            this.setState({ restaurentData: nextProps.restaurentDetailApis.restaurentData });
            this.props.dispatch(getRestaurantReviews({ id: this.state.rest_id, start: 0, count: constants.review_Limit }))
        }
    }
    renderReviews(item, id) {
        if(item.review.review_text)
        return (<li key={id}>
            <p>{item.review.review_text ? item.review.review_text : null}</p>
        </li>);
    }
    handleThumbnailLoadError=(event)=>{
        event.target.src = DefaultProductThumbnailIcon;
    }
    renderHeight=()=>{
        return window.innerHeight - 50+'px';
    }
    renderFacetHeight(){
        if(document.getElementsByClassName('facets')[0]){
            let position = document.getElementsByClassName('facets')[0].getBoundingClientRect();
            let finalValue = window.innerHeight - (position.top + position.height) - 50;
            return finalValue+'px';
        }
    }
    setFacet=(itm,id)=>{
        // console.log(itm);
        let tempState = Object.assign({},this.state);
        if(tempState.facets && tempState.facets.length){
            tempState.facets.forEach((itm)=>{
                itm.isSelected = false
            });
        }
        let selectedItem = tempState.facets.filter((itm,idx)=>{
            return idx == id
        });
        if(selectedItem.length){
            selectedItem[0].isSelected = true;
            tempState.selectedView = selectedItem[0].value;
            this.setState(tempState);
        }
    }
    listPaneDidMount=(node)=>{
        if (node) {
            node.addEventListener('scroll', this.handleListScroll);
        }
    }
    handleListScroll=(event)=>{
        var node = event.target;
        const bottom = node.scrollHeight - node.scrollTop === node.clientHeight;
        if (bottom) {
            console.log('BOTTOM REACHED:', bottom);
            this.fetchMoreReviews();
        }
    }
    fetchMoreReviews=()=>{
        const totalItemCount = this.props.restaurentDetailApis.reviewData.reviews_count;
        let curentNumber = this.props.restaurentDetailApis.reviewData && this.props.restaurentDetailApis.reviewData.user_reviews && this.props.restaurentDetailApis.reviewData.user_reviews.length ? this.props.restaurentDetailApis.reviewData.user_reviews.length : 0;
        if (
            !this.props.restaurentDetailApis.gettingRestaurentReviewsFailure &&
            (!totalItemCount || totalItemCount > this.props.restaurentDetailApis.reviewData.user_reviews.length)
        ) {
            this.props.dispatch(getRestaurantReviews({ id: this.state.rest_id, start: curentNumber, count: constants.review_Limit, total: totalItemCount}));
        }
    }
    render() {
        return (<div>
             <div className="overlay" style={{display: (this.props.restaurentDetailApis.gettingRestaurentDetails || this.props.restaurentDetailApis.gettingRestaurentReviews) ? "block" : "none"}}>
                    <div className="loading"><SvgLoading /></div>
            </div>
            <Header showLogo={true} showLocationFinder={false} showSearchRestaurent={false} findLocation={() => { }} searchRestaurent={false} locationName={false} />
            <div className="mainContainer" style={{height:this.renderHeight()}}>
                <div className="restaurentMainInfo">
                    <div className="restImage">
                    <LazyLoad height={100} offset={500} once>
                        <img className={`restaurentImg`} width="100"
                            alt={'Restaurent Logo'}
                            src={this.state.restaurentData.thumb}
                            onError={this.handleThumbnailLoadError}
                        />
                    </LazyLoad>
                    </div>
                    <div className="nameCusine">
                        <div><h4>{this.state.restaurentData.name ? this.state.restaurentData.name : 'Restaurant name not available'}</h4></div>
                        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <div><h5>Cuisines:</h5> </div>
                    &nbsp;
                <div>{this.state.restaurentData.cuisines && this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? this.state.restaurentData.cuisines : '-'} {this.state.restaurentData.cuisines && this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? '-' : null} {this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? this.state.restaurentData.establishment.join(', ') : 'No Specail establishments available'}</div>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <div><h5>Location:</h5></div>
                    &nbsp;
                    <div>{this.state.restaurentData.location ? this.state.restaurentData.location.locality : '-'}</div>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <h5>Timings:</h5>
                    &nbsp;
                    {this.state.restaurentData.timings ? this.state.restaurentData.timings : 'Opens 24hrs. in a day'}
                        </div>
                    </div>
                    <div className="nameCusine ratingInfo">
                        {this.state.restaurentData.user_rating && (<div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <h5>Rating:</h5>
                    &nbsp;
                            <SvgIcon glyph={StarIcon} width={'12px'} height={'12px'} />&nbsp;{this.state.restaurentData.user_rating.aggregate_rating}
                        </div>)}
                        {this.state.restaurentData.phone_numbers && (<div style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <h5>Call us:</h5>
                    &nbsp;
                            {this.state.restaurentData.phone_numbers ? this.state.restaurentData.phone_numbers : 'Number not available'}
                        </div>)}
                    </div>
                </div>
                <div className="facets">
                    <div>
                        <ul className="facetList">
                            {this.state.facets.map((itm,idx)=>(<li key={idx} onClick={(event)=>this.setFacet(itm,idx)} className={itm.isSelected ? "facet selected":"facet notSelected"}>
                                <div className={itm.isSelected ? "facetValue selected":"facetValue notSelected"}>{itm.value}</div>
                            </li>))}
                        </ul>
                    </div>
                </div>
                {this.state.selectedView == 'Highlights' ? (<div>
                    {this.state.selectedView == 'Highlights' && this.state.restaurentData.highlights && this.state.restaurentData.highlights.length ? (<div style={{paddingLeft:'40px',height:this.renderFacetHeight(),overflow:'scroll'}}>
                    <ul style={{listStyleType:'decimal',padding:'0',lineHeight:'2em'}}>
                        {this.state.restaurentData.highlights.map((item,id)=>(<li key={id}>
                            {item}
                        </li>)
                        )}
                    </ul>
                    <div className="nameCusine">
                        <h4>Average Cost: </h4>
                        {this.state.restaurentData.average_cost_for_two} for two people (approx.)
                    </div>
                </div>):(<div className="restaurentMainInfo"><div style={{padding:'2%'}}><p>No Highlights Available...!</p></div></div>)}
                </div>):null}
                {this.state.selectedView == 'Reviews' ? (<div>
                    {this.state.selectedView == 'Reviews' && this.props.restaurentDetailApis.reviewData && this.props.restaurentDetailApis.reviewData.user_reviews && this.props.restaurentDetailApis.reviewData.user_reviews.length ? (<div className="reviewArea">
                    <ul ref={this.listPaneDidMount} style={{height:this.renderFacetHeight(),overflow:'scroll',listStyleType:'decimal',lineHeight:'1em'}}>
                        {this.props.restaurentDetailApis.reviewData.user_reviews.map((item, id) => this.renderReviews(item, id))}
                    </ul>
                </div>) : (<div className="restaurentMainInfo"><div style={{padding:'2%'}}><p>No Reviews Available...!</p></div></div>)}
                </div>):null}
            </div>
        </div>);
    }
}

function mapStateToProps(state) {
    return {
        homeApis: state.homeApis,
        restaurentDetailApis: state.restaurentDetailApis
    };
}
export default connect(mapStateToProps)(RestaurantDetail);