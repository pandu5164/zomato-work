import actions from './index';
import constants from '../constants';
import urls from '../urls';
import {commonHeaders, checkHttpStatus} from '../utils';

export function getRestaurantDetail(data) {
    return function (dispatch, getState) {
        const state = getState();
        dispatch({
            type: actions.GET_RESTAURENT_DETAIL,
        });
        let customizedHeaders = {...commonHeaders}
        return fetch(constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_DETAIL + '?res_id='+data , {
            method: 'GET',
            headers: customizedHeaders,
        }).then(checkHttpStatus)
        .then(response=>{
            dispatch({
                type:actions.GET_RESTAURENT_DETAIL_SUCCESS,
                data: response
            })
        })
        .catch(error=>{
            dispatch({
                type:actions.GET_RESTAURENT_DETAIL_FAILURE,
                errorMessage: error
            })
        })
    }
};

export function getRestaurantReviews(data) {
    return function (dispatch, getState) {
        const state = getState();
        dispatch({
            type: actions.GET_RESTAURENT_REVIEW,
        });
        let customizedHeaders = {...commonHeaders}
        let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_REVIEW + '?res_id='+data.id;
        if(data.start){
            url += '&start='+data.start;
        }
        if(data.count){
            url += '&count='+data.count;
        }
        return fetch(url, {
            method: 'GET',
            headers: customizedHeaders,
        }).then(checkHttpStatus)
        .then(response=>{
            dispatch({
                type:actions.GET_RESTAURENT_REVIEW_SUCCESS,
                data: response
            })
        })
        .catch(error=>{
            dispatch({
                type:actions.GET_RESTAURENT_REVIEW_FAILURE,
                errorMessage: error
            })
        })
    }
};