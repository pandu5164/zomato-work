import actions from '../actions/index';
const initialState = {
    error: null,
    gettingRestaurentDetails: null,
    gettingRestaurentDetailsSuccess: null,
    gettingRestaurentDetailsFailure: null,
    restaurentData: {},
    gettingRestaurentReviews: null,
    gettingRestaurentReviewsSuccess:null,
    gettingRestaurentReviewsFailure:null,
    reviewData: {}
}

export default function restaurentDetailApis(state = initialState, action){
    switch(action.type){
        case actions.GET_RESTAURENT_DETAIL: {
            return Object.assign({}, state, {
                gettingRestaurentDetails: true,
                gettingRestaurentDetailsSuccess: false,
                gettingRestaurentDetailsFailure: false,
                restaurentData: {}
            });
        }
        case actions.GET_RESTAURENT_DETAIL_SUCCESS: {
            return Object.assign({}, state, {
                gettingRestaurentDetails: false,
                gettingRestaurentDetailsSuccess: true,
                gettingRestaurentDetailsFailure: false,
                restaurentData: action.data
            });
        }
        case actions.GET_RESTAURENT_DETAIL_FAILURE: {
            return Object.assign({}, state, {
                gettingRestaurentDetails: false,
                gettingRestaurentDetailsSuccess: false,
                gettingRestaurentDetailsFailure: true,
                error: action.errorMessage
            });
        }
        case actions.GET_RESTAURENT_REVIEW: {
            return Object.assign({}, state, {
                gettingRestaurentReviews: true,
                gettingRestaurentReviewsSuccess: false,
                gettingRestaurentReviewsFailure: false,
            });
        }
        case actions.GET_RESTAURENT_REVIEW_SUCCESS: {
            let reviewList = [];
            if (state.reviewData && state.reviewData.user_reviews) {
                reviewList = state.reviewData.user_reviews.concat(action.data.user_reviews);
                action.data.user_reviews = reviewList;
            } else if (state.reviewData && state.reviewData.user_reviews) {
                reviewList = action.data.user_reviews;
                action.data.user_reviews = reviewList;
            }
            return Object.assign({}, state, {
                gettingRestaurentReviews: false,
                gettingRestaurentReviewsSuccess: true,
                gettingRestaurentReviewsFailure: false,
                reviewData: action.data
            });
        }
        case actions.GET_RESTAURENT_REVIEW_FAILURE: {
            return Object.assign({}, state, {
                gettingRestaurentReviews: false,
                gettingRestaurentReviewsSuccess: false,
                gettingRestaurentReviewsFailure: true,
                error: action.errorMessage
            });
        }
        default:{
            return state;
        }
    }
}