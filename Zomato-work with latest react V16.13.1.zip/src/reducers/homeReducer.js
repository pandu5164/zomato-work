import actions from '../actions/index';
const initialState = {
 error: null,
 fetchingLocationData: false,
 fetchedLocationDataSuccess: false,
 fetchedLocationDataFailure: false,
 fetchedLocationData: null,
 searchingRestaurents: false,
 searchingRestaurentsSuccess: null,
 searchingRestaurentsFailure: null,
 searchRestaurentsResultData: {}
};
export default function homeApis(state = initialState, action){
    switch(action.type){
        case actions.GET_LOCATION_DATA:{
            return Object.assign({}, state, {
                fetchingLocationData: true,
                fetchedLocationDataSuccess: false,
                fetchedLocationDataFailure: false,
                fetchedLocationData: null
            });
        }
        case actions.GET_LOCATION_DATA_SUCCESS: {
            return Object.assign({}, state, {
                fetchingLocationData: false,
                fetchedLocationDataSuccess: true,
                fetchedLocationDataFailure: false,
                fetchedLocationData: action.data
            });
        }
        case actions.GET_LOCATION_DATA_FAILURE:{
            return Object.assign({}, state, {
                fetchingLocationData: false,
                fetchedLocationDataSuccess: false,
                fetchedLocationDataFailure: true,
                fetchLocationError: action.errorMessage
            });
        }
        case actions.GET_RESTAURENT_SEARCH_DATA: {
            return Object.assign({}, state, {
                searchingRestaurents: true,
                searchingRestaurentsSuccess: false,
                searchingRestaurentsFailure: false,
                searchRestaurentsResultData: null
            });
        }
        case actions.GET_RESTAURENT_DATA: {
            return Object.assign({}, state, {
                searchingRestaurents: true,
                searchingRestaurentsSuccess: false,
                searchingRestaurentsFailure: false,
                searchRestaurentsResultData: action.isReset ? null : state.searchRestaurentsResultData
            });
        }
        case actions.GET_RESTAURENT_DATA_SUCCESS: {
            let orderList = [];
            if (state.searchRestaurentsResultData && state.searchRestaurentsResultData.restaurants) {
                orderList = state.searchRestaurentsResultData.restaurants.concat(action.data.restaurants);
                action.data.restaurants = orderList;
            } else if (state.searchRestaurentsResultData && state.searchRestaurentsResultData.restaurants) {
                orderList = action.data.restaurants;
                action.data.restaurants = orderList;
            }
            return Object.assign({}, state, {
                searchingRestaurents: false,
                searchingRestaurentsSuccess: true,
                searchingRestaurentsFailure: false,
                searchRestaurentsResultData: action.data
            });
        }
        case actions.GET_RESTAURENT_DATA_FAILURE: {
            return Object.assign({}, state, {
                searchingRestaurents: false,
                searchingRestaurentsSuccess: false,
                searchingRestaurentsFailure: true,
                error: action.errorMessage
            })
        }
        default: {
            return state;
        }
    }
}