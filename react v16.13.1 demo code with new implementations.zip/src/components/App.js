import React, { Component } from 'react';
import actions from '../actions/index';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render(){
        return (<div>
            {this.props.children}
        </div>)
    }
}

function mapStateToProps(state) {
    return {
        userAccount: {}
    };
}
export default connect(mapStateToProps)(App);