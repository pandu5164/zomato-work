(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ "./src/actions/homeActions.js":
/*!************************************!*\
  !*** ./src/actions/homeActions.js ***!
  \************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index */ "./src/actions/index.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _urls__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../urls */ "./src/urls.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ "./src/utils.js");



 // export function getLocationData(lat,long) {
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_LOCATION_DATA,
//         });
//         let customizedHeaders = {...commonHeaders}
//         let url = new URL(constants.BASE_API_URL + constants.apiPoint + urls.GET_CITY_BY_LOCATION + '?');
//         let params = new URLSearchParams(url.search.slice(1));
//         params.append('lat', lat); //no support for IE browser
//         params.append('lon', long);
//         let finalUrl = url + params
//         // let finalUrl = constants.BASE_API_URL + constants.apiPoint + urls.GET_CITY_BY_LOCATION + '?lat='+lat+'&lon='+long;
//         return fetch(finalUrl, {
//             method: 'GET',
//             headers: customizedHeaders,
//         }).then(checkHttpStatus)
//         .then(response=>{
//             dispatch({
//                 type:actions.GET_LOCATION_DATA_SUCCESS,
//                 data: response
//             })
//         })
//         .catch(error=>{
//             dispatch({
//                 type:actions.GET_LOCATION_DATA_FAILURE,
//                 errorMessage: error
//             })
//         })
//     }
// };
// export function getRestaurentData(data) {
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_RESTAURENT_DATA,
//             isReset: data.isForceRefreshList ? true : false
//         });
//         let customizedHeaders = {...commonHeaders}
//         // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
//         // if(data.searchword){
//         //     url += '&q='+data.searchword;
//         // }
//         // if(data.count){
//         //     url += '&count='+data.count;
//         // }
//         // if(data.lat){
//         //     url += '&lat='+data.lat;
//         // }
//         // if(data.lon){
//         //     url += '&lon='+data.lon;
//         // }
//         // if(data.start){
//         //     url += '&start='+data.start;
//         // }
//         // if(data.radius){
//         //     url += '&radius='+data.radius;
//         // }
//         // if(data.sort){
//         //     url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
//         // } else {
//         //     url += '&sort=real_distance';
//         // }
//         // if(data.order){
//         //     url += data.order ? '&order='+data.order : '&order=desc';
//         // } else {
//         //     url += '&order=desc';
//         // }
//         let params = {
//             entity_id: data.entity_id,
//             entity_type: data.entity_type,
//             q: data.searchword ? data.searchword : '',
//             count: data.count,
//             lat: data.lat,
//             lon: data.lon,
//             start: data.start,
//             radius: data.radius ? data.radius : '',
//             sort: data.sort ? data.sort : 'real_distance',
//             order: data.order ? data.order : 'desc'
//         }
//         let queryParams = Object.keys(params)
//             .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
//             .join('&');
//         let finalUrl = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?' + queryParams;
//         return fetch(finalUrl , {
//             method: 'GET',
//             headers: customizedHeaders,
//         }).then(checkHttpStatus)
//         .then(response=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DATA_SUCCESS,
//                 data: response
//             })
//         })
//         .catch(error=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DATA_FAILURE,
//                 errorMessage: error
//             })
//         })
//     }
// };
// export function searchRestaurentData(data){
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_RESTAURENT_SEARCH_DATA,
//         });
//         let customizedHeaders = {...commonHeaders}
//         // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
//         // if(data.searchword){
//         //     url += '&q='+data.searchword;
//         // }
//         // if(data.count){
//         //     url += '&count='+data.count;
//         // }
//         // if(data.lat){
//         //     url += '&lat='+data.lat;
//         // }
//         // if(data.lon){
//         //     url += '&lon='+data.lon;
//         // }
//         // if(data.start){
//         //     url += '&start='+data.start;
//         // }
//         // if(data.radius){
//         //     url += '&radius='+data.radius;
//         // }
//         // if(data.sort){
//         //     url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
//         // } else {
//         //     url += '&sort=real_distance';
//         // }
//         // if(data.order){
//         //     url += data.order ? '&order='+data.order : '&order=desc';
//         // } else {
//         //     url += '&order=desc';
//         // }
//         let params = {
//             entity_id: data.entity_id,
//             entity_type: data.entity_type,
//             q:data.searchword ? data.searchword : '',
//             count: data.count,
//             lat: data.lat,
//             lon: data.lon,
//             start: data.start,
//             radius: data.radius ? data.radius : '',
//             sort: data.sort ? data.sort : 'real_distance',
//             order: data.order ? data.order : 'desc'
//         }
//         let queryParams = Object.keys(params)
//             .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
//             .join('&');
//         let finalUrl = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?' + queryParams
//         return fetch(finalUrl , {
//             method: 'GET',
//             headers: customizedHeaders,
//         }).then(checkHttpStatus)
//         .then(response=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DATA_SUCCESS,
//                 data: response
//             })
//         })
//         .catch(error=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DATA_FAILURE,
//                 errorMessage: error
//             })
//         })
//     }
// }

/***/ }),

/***/ "./src/assets/images/sapient.png":
/*!***************************************!*\
  !*** ./src/assets/images/sapient.png ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "804308cb758b9f3fa3cfcc6bbe2ef9b8.png");

/***/ }),

/***/ "./src/components/Home.js":
/*!********************************!*\
  !*** ./src/components/Home.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-router-redux */ "./node_modules/react-router-redux/lib/index.js");
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_router_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-waypoint */ "./node_modules/react-waypoint/es/index.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils */ "./src/utils.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _presentations_Header__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../presentations/Header */ "./src/presentations/Header.js");
/* harmony import */ var _actions_homeActions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../actions/homeActions */ "./src/actions/homeActions.js");
/* harmony import */ var _presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../presentations/SvgLoading */ "./src/presentations/SvgLoading.js");
/* harmony import */ var _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../assets/images/sapient.png */ "./src/assets/images/sapient.png");






function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }



 // import { Link } from 'react-router';






 // import SvgIcon from '../presentations/SvgIcon';

 // import StarIcon from '../assets/images/ic-star-full.svg';



var Home = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(Home, _Component);

  var _super = _createSuper(Home);

  // constructor(props) {
  //     super(props);
  //     this.state = {
  //         name : 'pavan',
  //         locationData: {},
  //         restaurentsData: {},
  //         searchKey: null,
  //         loadOnScroll: true,
  //         toggleresize: false,
  //         isForceRefreshList: false,
  //         isRateSorted: false,
  //         windowHeight:window.innerHeight,
  //         possibleSortValues: [
  //             {id:0, value:'cost', displayName: 'Cost'},
  //             {id:1, value:'rating', displayName: 'Rating'},
  //             {id:2, value: 'real_distance', displayName: 'Distance'}
  //         ],
  //         possiblOrderValues: [
  //             {id:0,value:'asc',displayName:'Ascending'},
  //             {id:1,value:'desc',displayName:'Descending'}
  //         ],
  //         searchData: {
  //             entity_id: null,
  //             entity_type: null,
  //             searchword: null,
  //             count: constants.list_Limit,
  //             lat: null,
  //             lon: null,
  //             radius: null,
  //             sort: null,
  //             order: null,
  //             start: 0,
  //             results_found: null
  //         },
  //         makeApiCalls: this.makeApiCalls.bind(this)
  //     }
  //     // this.showPosition = this.showPosition.bind(this);
  //     // this.getEndOfListMarkup = this.getEndOfListMarkup.bind(this);
  //     // this.fetchMoreCards = debounce(this.fetchMoreCards, 500, this);
  //     // this.resizeList = debounce(this.resizeList,1000,this);
  //     // this.listPaneDidMount = this.listPaneDidMount.bind(this);
  //     // this.handleListScroll = this.handleListScroll.bind(this);
  //     // this.rateSort = this.rateSort.bind(this);
  //     // this.goToDetailPage = this.goToDetailPage.bind(this);
  // }
  // componentDidMount(){
  //     this.getLocation();
  //     window.addEventListener('resize',this.resizeList);
  // }
  // componentWillUnmount(){
  //     window.removeEventListener('resize',this.resizeList);
  // }
  // // componentWillReceiveProps(nextProps){
  // //     if(this.props.homeApis.fetchingLocationData && nextProps.homeApis.fetchedLocationDataSuccess && nextProps.homeApis.fetchedLocationData){
  // //         this.setState({locationData : nextProps.homeApis.fetchedLocationData});
  // //         if(nextProps.homeApis.fetchedLocationData.location){
  // //             let reqData = nextProps.homeApis.fetchedLocationData.location;
  // //             let searchData = {
  // //                 entity_id: reqData.entity_id,
  // //                 entity_type: reqData.entity_type,
  // //                 searchword: this.state.searchKey,
  // //                 count: constants.list_Limit,
  // //                 lat: reqData.latitude,
  // //                 lon: reqData.longitude,
  // //                 radius: null,
  // //                 sort: null,
  // //                 order: null,
  // //                 start: 0,
  // //                 results_found: null
  // //             }
  // //             this.setState({searchData: searchData});
  // //             if(this.state.isForceRefreshList){
  // //                 searchData.isForceRefreshList =  this.state.isForceRefreshList;
  // //                 this.makeApiCalls('GET_RESTAURENTS_DATA',searchData);
  // //                 this.setState({isForceRefreshList: false});
  // //             }
  // //         }
  // //     }
  // //     if(nextProps.homeApis.searchRestaurentsResultData && nextProps.homeApis.searchingRestaurentsSuccess && this.props.homeApis.searchingRestaurents){
  // //         this.setState({restaurentsData: nextProps.homeApis.searchRestaurentsResultData, loadOnScroll: nextProps.homeApis.searchRestaurentsResultData.restaurants && nextProps.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
  // //     }
  // // }
  // static getDerivedStateFromProps(props,state){ // for componentReceiveProps
  //     // console.log(props);
  //         if(props.homeApis.fetchedLocationDataSuccess && props.homeApis.fetchedLocationData){ //props.homeApis.fetchingLocationData &&
  //         // this.setState({locationData : props.homeApis.fetchedLocationData});
  //         state.locationData = props.homeApis.fetchedLocationData;
  //         if(props.homeApis.fetchedLocationData.location){
  //             let reqData = props.homeApis.fetchedLocationData.location;
  //             let searchData = {
  //                 entity_id: reqData.entity_id,
  //                 entity_type: reqData.entity_type,
  //                 searchword: state.searchKey,
  //                 count: constants.list_Limit,
  //                 lat: reqData.latitude,
  //                 lon: reqData.longitude,
  //                 radius: null,
  //                 sort: null,
  //                 order: null,
  //                 start: 0,
  //                 results_found: null
  //             }
  //             // this.setState({searchData: searchData});
  //             state.searchData = searchData;
  //             if(state.isForceRefreshList){
  //                 searchData.isForceRefreshList =  state.isForceRefreshList;
  //                 state.makeApiCalls('GET_RESTAURENTS_DATA',searchData);
  //                 // this.setState({isForceRefreshList: false});
  //                 state.isForceRefreshList = false;
  //             }
  //         }
  //     }
  //     if(props.homeApis.searchRestaurentsResultData && props.homeApis.searchingRestaurentsSuccess){ // && props.homeApis.searchingRestaurents
  //         // this.setState({restaurentsData: props.homeApis.searchRestaurentsResultData, loadOnScroll: props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
  //         state.restaurentsData = props.homeApis.searchRestaurentsResultData;
  //         state.loadOnScroll = props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false
  //     }
  //     return state;
  // }
  // getSnapshotBeforeUpdate(prevProps, prevState){ // for componentWillUpdate
  //     return null;
  // }
  // componentDidUpdate(prevProps, prevState, snapshot){
  // }
  // resizeList=()=>{
  //     this.setState({toggleresize: !this.state.toggleresize, windowHeight: window.innerHeight});
  //     console.log('resized');
  // }
  // renderListHeight=()=> this.state.windowHeight - 150+'px';
  // getLocation=(type)=>{
  //     if (navigator.geolocation) {
  //       navigator.geolocation.getCurrentPosition(this.showPosition, this.locationFetchFail);
  //       if(type){
  //         this.setState({isForceRefreshList:type && type == 'force'});
  //       }
  //     } else { 
  //         alert('Geolocation is not supported by this browser');
  //     }
  //   }
  // locationFetchFail=(data)=>{
  //     alert(data.code === 1 ? 'Error: '+data.message+', Please allow browser to detect location':'Error: '+data.message+'');
  // }
  // makeApiCalls=(type, data)=>{
  //     if(type){
  //         switch(type){
  //             case 'GET_LOCATION_DATA':{
  //                 if(data)
  //                 return this.props.dispatch(getLocationData(data.latitude,data.longitude));
  //             }
  //             case 'GET_RESTAURENTS_DATA': {
  //                 if(data)
  //                 return this.props.dispatch(getRestaurentData(data));
  //             }
  //             case 'SEARCH_RESTAURENTS_DATA': {
  //                 if(data)
  //                 return this.props.dispatch(searchRestaurentData(data));
  //             }
  //             default: {
  //                 return null;
  //             }
  //         } 
  //     }
  // }
  // showPosition=(position)=>{
  //     let data = {
  //         latitude: position.coords.latitude,
  //         longitude: position.coords.longitude
  //     }
  //     this.makeApiCalls('GET_LOCATION_DATA',data);
  // }
  // getEndOfListMarkup=()=>{
  //     if (
  //         this.state.loadOnScroll &&
  //         !this.props.homeApis.searchingRestaurentsFailure &&
  //         !this.props.homeApis.searchingRestaurents
  //     ) {
  //         return <Waypoint onEnter={() => this.fetchMoreCards()} />;
  //     }
  // }
  // fetchMoreCards=()=>{
  //     const totalItemCount = this.props.homeApis.searchRestaurentsResultData.results_found;
  //     let curentNumber = this.props.homeApis.searchRestaurentsResultData && this.props.homeApis.searchRestaurentsResultData.restaurants && this.props.homeApis.searchRestaurentsResultData.restaurants.length ? this.props.homeApis.searchRestaurentsResultData.restaurants.length : 0;
  //     if (
  //         !this.props.homeApis.searchingRestaurentsFailure &&
  //         (!totalItemCount || totalItemCount > this.props.homeApis.searchRestaurentsResultData.restaurants.length)
  //     ) {
  //         let tempState = Object.assign({},this.state);
  //         tempState.searchData.results_found = totalItemCount;
  //         tempState.searchData.start = curentNumber;
  //         if(tempState.searchData.isForceRefreshList)
  //         tempState.searchData.isForceRefreshList = false;
  //         this.setState(tempState);
  //         this.makeApiCalls('GET_RESTAURENTS_DATA',tempState.searchData);
  //     }
  // }
  // handleThumbnailLoadError=(event)=>{
  //     event.target.src = DefaultProductThumbnailIcon;
  // }
  // goToDetailPage=(id)=>{
  //     this.props.dispatch(push('/restaurant/'+id));
  // }
  // renderRestaurents(item,id){
  //     return (<li key={id} onClick={(event)=>this.goToDetailPage(item.restaurant.id)}>
  //         {/* <Link
  //             className="detailRoute"
  //             href={'/restaurant/'+item.restaurant.id}
  //         > can also use to instead of href for seamless navigation without reloading destination page*/}
  //         <div className="imgHeader">
  //             <div style={{paddingLeft:'0.5em',width:'30%'}}>
  //                 <LazyLoad height={75} offset={500} once>
  //                     <img className={`restaurentImg`} width="75"
  //                         alt={'Restaurent Logo'}
  //                         src={item.restaurant.thumb}
  //                         onError={this.handleThumbnailLoadError}
  //                     />
  //                 </LazyLoad>
  //             </div>
  //             <div className="restAddr" style={{padding:'0px 10px',width:'45%','maxHeight': '-webkit-fill-available',overflow:'hidden'}}>
  //                 <p>{item.restaurant.location.address}</p>
  //             </div>
  //             <div style={{paddingRight:'0.5em',width:'25%'}}>
  //                 <h4 style={{maxWidth:'150px',textOverflow:'ellipsis',overflow:'hidden',whiteSpace:'nowrap'}}>{item.restaurant.name}</h4>
  //                 <div className="rating" style={{textOverflow:'ellipsis',overflow:'hidden',whiteSpace:'nowrap',display:'flex'}}>
  //                     {/* <LazyLoad height={20} offset={500} once><img src={StarIcon} width="12px" /></LazyLoad> */}
  //                     <span style={{paddingLeft:'5px'}}>{item.restaurant.user_rating.aggregate_rating ?item.restaurant.user_rating.aggregate_rating : '0'}&nbsp;<span style={{color:'#E23744'}}>(Votes: {item.restaurant.user_rating.votes})</span></span>
  //                 </div>
  //             </div>
  //         </div>
  //         <hr style={{width:'100%',border:'none',height:'0.5px',background:'#9a9a9a'}} />
  //         <div style={{display:'flex',justifyContent:'space-between',width:'100%'}}>
  //             <div>Cost for two : {item.restaurant.average_cost_for_two}</div>
  //             <div style={{textOverflow:'ellipsis',overflow:'hidden',maxWidth:'200px',whiteSpace:'nowrap'}}>Hours: {item.restaurant.timings}</div>
  //         </div>
  //         {/* </Link> */}
  //     </li>)
  // }
  // listPaneDidMount = (node) => {
  //     if (node) {
  //         node.addEventListener('scroll', this.handleListScroll);
  //     }
  // };
  // handleListScroll=(event)=>{
  //     var node = event.target;
  //     const bottom = node.scrollHeight - node.scrollTop === node.clientHeight;
  //     if (bottom) {
  //         // console.log('BOTTOM REACHED:', bottom);
  //         this.fetchMoreCards();
  //     }
  // }
  // searchByKeyword=(event)=>{
  //     if(event && event.target){
  //         let searchText = event.target.value;
  //         let searchData = this.state.searchData;
  //         let tempState = Object.assign({},this.state);
  //         tempState.searchKey = searchText;
  //         tempState.searchData.searchword = searchText;
  //         tempState.searchData.start = 0;
  //         this.setState({searchKey:searchText});
  //         this.makeApiCalls('SEARCH_RESTAURENTS_DATA',tempState.searchData);
  //     }
  // }
  // rateSort=()=>{
  //     let tempState = Object.assign({},this.state);
  //     let currentState = tempState.isRateSorted;
  //     tempState.searchData.start = 0;
  //     if(currentState){
  //         tempState.searchData.sort = 'real_distance';
  //     } else {
  //         tempState.searchData.sort = 'rating';
  //     }
  //     tempState.isRateSorted = !tempState.isRateSorted;
  //     this.setState(tempState);
  //     this.makeApiCalls('SEARCH_RESTAURENTS_DATA',tempState.searchData);
  // }
  function Home(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Home);

    _this = _super.call(this, props);
    _this.state = {};
    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Home, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "overlay",
        style: {
          display: this.props.homeApis.fetchingLocationData || this.props.homeApis.searchingRestaurents ? "block" : "none"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: "loading"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_14__["default"], null))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_presentations_Header__WEBPACK_IMPORTED_MODULE_12__["default"], null));
    }
  }]);

  return Home;
}(react__WEBPACK_IMPORTED_MODULE_5__["Component"]);

function mapStateToProps(state) {
  return {
    homeApis: state.homeApis
  };
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_6__["connect"])(mapStateToProps)(Home));

/***/ }),

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var constants = {
  BASE_API_URL: 'https://developers.zomato.com',
  apiPoint: '/api/v2.1',
  zomatoPublicKey: '2eb74a3c6ef3eda909d00007cdf72e00',
  list_Limit: 20,
  review_Limit: 10,
  COLORS: {
    PUMPKIN_ORANGE: '#f57b02',
    HINT_OF_RED: '#F9F9F9',
    SCARLET: '#D0021B'
  },
  FETCH_RETRY_TIMEOUT_IN_SECONDS: 3
};
/* harmony default export */ __webpack_exports__["default"] = (constants);

/***/ }),

/***/ "./src/presentations/Header.js":
/*!*************************************!*\
  !*** ./src/presentations/Header.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Header; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../assets/images/sapient.png */ "./src/assets/images/sapient.png");



 // import location from '../assets/images/location.png'

function Header(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("b", null, "SpacEx Launch Program"))); // return(<div className="header-zomato">
  //     {props.showLogo ? (<div style={{paddingLeft:'1em'}}>
  //     <LazyLoad height={'auto'} offset={500} once>
  //         <img className={`logoImg`} width="75"
  //             alt={'Zomato'}
  //             src={logo}
  //         />
  //     </LazyLoad>
  //     </div>):null}
  //     {props.showSearchRestaurent ? (<div>
  //         <input type="text" onChange={props.searchRestaurent} placeholder="Search for Restaurants"/>
  //     </div>):null}
  //     {props.showLocationFinder ? (<div className="locationArea" onClick={props.findLocation} style={{cursor:'pointer',paddingRight:'1em',display:'flex',alignItems:'center'}}>
  //         <p style={{paddingRight:'5px'}}>{props.locationName}</p>
  //         <span>
  //             {/* <LazyLoad height={15} offset={500} once>
  //                 <img className={`locationImg`} width="15"
  //                     alt={'Locate'}
  //                     src={location}
  //                     style={{background:'#fff',borderRadius:'10px'}}
  //                 />
  //             </LazyLoad> */}
  //         </span>
  //     </div>) : null}
  // </div>);
}
;

/***/ }),

/***/ "./src/presentations/SvgLoading.js":
/*!*****************************************!*\
  !*** ./src/presentations/SvgLoading.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SvgLoading; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.js");


function SvgLoading(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
    width: "72px",
    height: "72px",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 100 100",
    preserveAspectRatio: "xMidYMid",
    className: "uil-ring"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("rect", {
    x: "0",
    y: "0",
    width: "100",
    height: "100",
    fill: "none",
    className: "bk"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("circle", {
    cx: "50",
    cy: "50",
    r: "45",
    strokeDasharray: "183.7831702350029 98.96016858807849",
    stroke: _constants__WEBPACK_IMPORTED_MODULE_1__["default"].COLORS.SCARLET,
    fill: "none",
    strokeWidth: "10"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("animateTransform", {
    attributeName: "transform",
    type: "rotate",
    values: "0 50 50;180 50 50;360 50 50;",
    keyTimes: "0;0.5;1",
    dur: "1s",
    repeatCount: "indefinite",
    begin: "0s"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
    className: "pumpkin-orange",
    style: {
      marginTop: '0.7em'
    }
  }, "Loading"));
}

/***/ }),

/***/ "./src/urls.js":
/*!*********************!*\
  !*** ./src/urls.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  GET_CITY_BY_LOCATION: '/geocode',
  GET_RESTAURENTS_BY_LOCATION: '/search',
  GET_RESTAURENT_DETAIL: '/restaurant',
  GET_RESTAURENT_REVIEW: '/reviews'
});

/***/ }),

/***/ "./src/utils.js":
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/*! exports provided: commonHeaders, checkHttpStatus, debounce, fetch_retry */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commonHeaders", function() { return commonHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkHttpStatus", function() { return checkHttpStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "debounce", function() { return debounce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetch_retry", function() { return fetch_retry; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./src/constants.js");



var commonHeaders = {
  Accept: 'application/json',
  'Content-Type': 'application/json; charset=UTF-8',
  'user-key': _constants__WEBPACK_IMPORTED_MODULE_2__["default"].zomatoPublicKey
};
function checkHttpStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response.json();
  } else {
    var error = new Error(response.statusText);
    error.response = response;
    throw error;
  }
}
;
function debounce(func, wait, context) {
  var timeout, args, timestamp, result;

  var later = function later() {
    var last = Date.now() - timestamp;

    if (last < wait && last >= 0) {
      timeout = setTimeout(later, wait - last);
    } else {
      timeout = null;
      result = func.apply(context, args);
      args = null;
    }
  };

  return function () {
    args = arguments;
    timestamp = Date.now();

    if (!timeout) {
      timeout = setTimeout(later, wait);
    }

    return result;
  };
}
;
var fetch_retry = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(fetch, retryAttempt, retryAfter) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return fetch();

          case 3:
            return _context.abrupt("return", _context.sent);

          case 6:
            _context.prev = 6;
            _context.t0 = _context["catch"](0);

            if (!(retryAttempt <= 1)) {
              _context.next = 10;
              break;
            }

            throw _context.t0;

          case 10:
            _context.next = 12;
            return new Promise(function (resolve) {
              var timeout = retryAfter;

              if (timeout === undefined || timeout === null) {
                timeout = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].FETCH_RETRY_TIMEOUT_IN_SECONDS;
              }

              setTimeout(resolve, timeout * 1000);
            }).then(function () {
              return fetch_retry(fetch, retryAttempt - 1, retryAfter);
            });

          case 12:
            return _context.abrupt("return", _context.sent);

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 6]]);
  }));

  return function fetch_retry(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

/***/ })

}]);