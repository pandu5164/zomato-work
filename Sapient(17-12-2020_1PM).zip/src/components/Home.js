import React, { Component } from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
// import { Link } from 'react-router';
import { Waypoint } from 'react-waypoint';
import LazyLoad from 'react-lazy-load';
import { debounce } from '../utils';
import constants from '../constants'
import Header from '../presentations/Header';
import {getLocationData, getRestaurentData, searchRestaurentData} from '../actions/homeActions';
// import SvgIcon from '../presentations/SvgIcon';
import SvgLoading from '../presentations/SvgLoading';
// import StarIcon from '../assets/images/ic-star-full.svg';
import DefaultProductThumbnailIcon from '../assets/images/sapient.png';
class Home extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         name : 'pavan',
    //         locationData: {},
    //         restaurentsData: {},
    //         searchKey: null,
    //         loadOnScroll: true,
    //         toggleresize: false,
    //         isForceRefreshList: false,
    //         isRateSorted: false,
    //         windowHeight:window.innerHeight,
    //         possibleSortValues: [
    //             {id:0, value:'cost', displayName: 'Cost'},
    //             {id:1, value:'rating', displayName: 'Rating'},
    //             {id:2, value: 'real_distance', displayName: 'Distance'}
    //         ],
    //         possiblOrderValues: [
    //             {id:0,value:'asc',displayName:'Ascending'},
    //             {id:1,value:'desc',displayName:'Descending'}
    //         ],
    //         searchData: {
    //             entity_id: null,
    //             entity_type: null,
    //             searchword: null,
    //             count: constants.list_Limit,
    //             lat: null,
    //             lon: null,
    //             radius: null,
    //             sort: null,
    //             order: null,
    //             start: 0,
    //             results_found: null
    //         },
    //         makeApiCalls: this.makeApiCalls.bind(this)
    //     }
    //     // this.showPosition = this.showPosition.bind(this);
    //     // this.getEndOfListMarkup = this.getEndOfListMarkup.bind(this);
    //     // this.fetchMoreCards = debounce(this.fetchMoreCards, 500, this);
    //     // this.resizeList = debounce(this.resizeList,1000,this);
    //     // this.listPaneDidMount = this.listPaneDidMount.bind(this);
    //     // this.handleListScroll = this.handleListScroll.bind(this);
    //     // this.rateSort = this.rateSort.bind(this);
    //     // this.goToDetailPage = this.goToDetailPage.bind(this);
    // }
    // componentDidMount(){
    //     this.getLocation();
    //     window.addEventListener('resize',this.resizeList);
    // }
    // componentWillUnmount(){
    //     window.removeEventListener('resize',this.resizeList);
    // }
    // // componentWillReceiveProps(nextProps){
    // //     if(this.props.homeApis.fetchingLocationData && nextProps.homeApis.fetchedLocationDataSuccess && nextProps.homeApis.fetchedLocationData){
    // //         this.setState({locationData : nextProps.homeApis.fetchedLocationData});
    // //         if(nextProps.homeApis.fetchedLocationData.location){
    // //             let reqData = nextProps.homeApis.fetchedLocationData.location;
    // //             let searchData = {
    // //                 entity_id: reqData.entity_id,
    // //                 entity_type: reqData.entity_type,
    // //                 searchword: this.state.searchKey,
    // //                 count: constants.list_Limit,
    // //                 lat: reqData.latitude,
    // //                 lon: reqData.longitude,
    // //                 radius: null,
    // //                 sort: null,
    // //                 order: null,
    // //                 start: 0,
    // //                 results_found: null
    // //             }
    // //             this.setState({searchData: searchData});
    // //             if(this.state.isForceRefreshList){
    // //                 searchData.isForceRefreshList =  this.state.isForceRefreshList;
    // //                 this.makeApiCalls('GET_RESTAURENTS_DATA',searchData);
    // //                 this.setState({isForceRefreshList: false});
    // //             }
    // //         }
    // //     }
    // //     if(nextProps.homeApis.searchRestaurentsResultData && nextProps.homeApis.searchingRestaurentsSuccess && this.props.homeApis.searchingRestaurents){
    // //         this.setState({restaurentsData: nextProps.homeApis.searchRestaurentsResultData, loadOnScroll: nextProps.homeApis.searchRestaurentsResultData.restaurants && nextProps.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
    // //     }
    // // }
    // static getDerivedStateFromProps(props,state){ // for componentReceiveProps
    //     // console.log(props);
    //         if(props.homeApis.fetchedLocationDataSuccess && props.homeApis.fetchedLocationData){ //props.homeApis.fetchingLocationData &&
    //         // this.setState({locationData : props.homeApis.fetchedLocationData});
    //         state.locationData = props.homeApis.fetchedLocationData;
    //         if(props.homeApis.fetchedLocationData.location){
    //             let reqData = props.homeApis.fetchedLocationData.location;
    //             let searchData = {
    //                 entity_id: reqData.entity_id,
    //                 entity_type: reqData.entity_type,
    //                 searchword: state.searchKey,
    //                 count: constants.list_Limit,
    //                 lat: reqData.latitude,
    //                 lon: reqData.longitude,
    //                 radius: null,
    //                 sort: null,
    //                 order: null,
    //                 start: 0,
    //                 results_found: null
    //             }
    //             // this.setState({searchData: searchData});
    //             state.searchData = searchData;
    //             if(state.isForceRefreshList){
    //                 searchData.isForceRefreshList =  state.isForceRefreshList;
    //                 state.makeApiCalls('GET_RESTAURENTS_DATA',searchData);
    //                 // this.setState({isForceRefreshList: false});
    //                 state.isForceRefreshList = false;
    //             }
    //         }
    //     }
    //     if(props.homeApis.searchRestaurentsResultData && props.homeApis.searchingRestaurentsSuccess){ // && props.homeApis.searchingRestaurents
    //         // this.setState({restaurentsData: props.homeApis.searchRestaurentsResultData, loadOnScroll: props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
    //         state.restaurentsData = props.homeApis.searchRestaurentsResultData;
    //         state.loadOnScroll = props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false
    //     }
    //     return state;
    // }
    // getSnapshotBeforeUpdate(prevProps, prevState){ // for componentWillUpdate
    //     return null;
    // }
    // componentDidUpdate(prevProps, prevState, snapshot){

    // }
    // resizeList=()=>{
    //     this.setState({toggleresize: !this.state.toggleresize, windowHeight: window.innerHeight});
    //     console.log('resized');
    // }

    // renderListHeight=()=> this.state.windowHeight - 150+'px';

    // getLocation=(type)=>{
    //     if (navigator.geolocation) {
    //       navigator.geolocation.getCurrentPosition(this.showPosition, this.locationFetchFail);
    //       if(type){
    //         this.setState({isForceRefreshList:type && type == 'force'});
    //       }
    //     } else { 
    //         alert('Geolocation is not supported by this browser');
    //     }
    //   }
    // locationFetchFail=(data)=>{
    //     alert(data.code === 1 ? 'Error: '+data.message+', Please allow browser to detect location':'Error: '+data.message+'');
    // }
    // makeApiCalls=(type, data)=>{
    //     if(type){
    //         switch(type){
    //             case 'GET_LOCATION_DATA':{
    //                 if(data)
    //                 return this.props.dispatch(getLocationData(data.latitude,data.longitude));
    //             }
    //             case 'GET_RESTAURENTS_DATA': {
    //                 if(data)
    //                 return this.props.dispatch(getRestaurentData(data));
    //             }
    //             case 'SEARCH_RESTAURENTS_DATA': {
    //                 if(data)
    //                 return this.props.dispatch(searchRestaurentData(data));
    //             }
    //             default: {
    //                 return null;
    //             }

    //         } 
    //     }
    // }
    // showPosition=(position)=>{
    //     let data = {
    //         latitude: position.coords.latitude,
    //         longitude: position.coords.longitude
    //     }
    //     this.makeApiCalls('GET_LOCATION_DATA',data);
    // }
    // getEndOfListMarkup=()=>{
    //     if (
    //         this.state.loadOnScroll &&
    //         !this.props.homeApis.searchingRestaurentsFailure &&
    //         !this.props.homeApis.searchingRestaurents
    //     ) {
    //         return <Waypoint onEnter={() => this.fetchMoreCards()} />;
    //     }
    // }
    // fetchMoreCards=()=>{
    //     const totalItemCount = this.props.homeApis.searchRestaurentsResultData.results_found;
    //     let curentNumber = this.props.homeApis.searchRestaurentsResultData && this.props.homeApis.searchRestaurentsResultData.restaurants && this.props.homeApis.searchRestaurentsResultData.restaurants.length ? this.props.homeApis.searchRestaurentsResultData.restaurants.length : 0;
    //     if (
    //         !this.props.homeApis.searchingRestaurentsFailure &&
    //         (!totalItemCount || totalItemCount > this.props.homeApis.searchRestaurentsResultData.restaurants.length)
    //     ) {
    //         let tempState = Object.assign({},this.state);
    //         tempState.searchData.results_found = totalItemCount;
    //         tempState.searchData.start = curentNumber;
    //         if(tempState.searchData.isForceRefreshList)
    //         tempState.searchData.isForceRefreshList = false;
    //         this.setState(tempState);
    //         this.makeApiCalls('GET_RESTAURENTS_DATA',tempState.searchData);
    //     }
    // }
    // handleThumbnailLoadError=(event)=>{
    //     event.target.src = DefaultProductThumbnailIcon;
    // }
    // goToDetailPage=(id)=>{
    //     this.props.dispatch(push('/restaurant/'+id));
    // }
    // renderRestaurents(item,id){
    //     return (<li key={id} onClick={(event)=>this.goToDetailPage(item.restaurant.id)}>
    //         {/* <Link
    //             className="detailRoute"
    //             href={'/restaurant/'+item.restaurant.id}
    //         > can also use to instead of href for seamless navigation without reloading destination page*/}
    //         <div className="imgHeader">
    //             <div style={{paddingLeft:'0.5em',width:'30%'}}>
    //                 <LazyLoad height={75} offset={500} once>
    //                     <img className={`restaurentImg`} width="75"
    //                         alt={'Restaurent Logo'}
    //                         src={item.restaurant.thumb}
    //                         onError={this.handleThumbnailLoadError}
    //                     />
    //                 </LazyLoad>
    //             </div>
    //             <div className="restAddr" style={{padding:'0px 10px',width:'45%','maxHeight': '-webkit-fill-available',overflow:'hidden'}}>
    //                 <p>{item.restaurant.location.address}</p>
    //             </div>
    //             <div style={{paddingRight:'0.5em',width:'25%'}}>
    //                 <h4 style={{maxWidth:'150px',textOverflow:'ellipsis',overflow:'hidden',whiteSpace:'nowrap'}}>{item.restaurant.name}</h4>
    //                 <div className="rating" style={{textOverflow:'ellipsis',overflow:'hidden',whiteSpace:'nowrap',display:'flex'}}>
    //                     {/* <LazyLoad height={20} offset={500} once><img src={StarIcon} width="12px" /></LazyLoad> */}
    //                     <span style={{paddingLeft:'5px'}}>{item.restaurant.user_rating.aggregate_rating ?item.restaurant.user_rating.aggregate_rating : '0'}&nbsp;<span style={{color:'#E23744'}}>(Votes: {item.restaurant.user_rating.votes})</span></span>
    //                 </div>
    //             </div>
    //         </div>
    //         <hr style={{width:'100%',border:'none',height:'0.5px',background:'#9a9a9a'}} />
    //         <div style={{display:'flex',justifyContent:'space-between',width:'100%'}}>
    //             <div>Cost for two : {item.restaurant.average_cost_for_two}</div>
    //             <div style={{textOverflow:'ellipsis',overflow:'hidden',maxWidth:'200px',whiteSpace:'nowrap'}}>Hours: {item.restaurant.timings}</div>
    //         </div>
    //         {/* </Link> */}
    //     </li>)
    // }
    // listPaneDidMount = (node) => {
    //     if (node) {
    //         node.addEventListener('scroll', this.handleListScroll);
    //     }
    // };
    // handleListScroll=(event)=>{
    //     var node = event.target;
    //     const bottom = node.scrollHeight - node.scrollTop === node.clientHeight;
    //     if (bottom) {
    //         // console.log('BOTTOM REACHED:', bottom);
    //         this.fetchMoreCards();
    //     }
    // }
    // searchByKeyword=(event)=>{
    //     if(event && event.target){
    //         let searchText = event.target.value;
    //         let searchData = this.state.searchData;
    //         let tempState = Object.assign({},this.state);
    //         tempState.searchKey = searchText;
    //         tempState.searchData.searchword = searchText;
    //         tempState.searchData.start = 0;
    //         this.setState({searchKey:searchText});
    //         this.makeApiCalls('SEARCH_RESTAURENTS_DATA',tempState.searchData);
    //     }
    // }
    // rateSort=()=>{
    //     let tempState = Object.assign({},this.state);
    //     let currentState = tempState.isRateSorted;
    //     tempState.searchData.start = 0;
    //     if(currentState){
    //         tempState.searchData.sort = 'real_distance';
    //     } else {
    //         tempState.searchData.sort = 'rating';
    //     }
    //     tempState.isRateSorted = !tempState.isRateSorted;
    //     this.setState(tempState);
    //     this.makeApiCalls('SEARCH_RESTAURENTS_DATA',tempState.searchData);
    // }

    constructor(props) {
        super(props);
        this.state={

        }
    }
    render(){
        return (<div>
            <div className="overlay" style={{display: (this.props.homeApis.fetchingLocationData || this.props.homeApis.searchingRestaurents) ? "block" : "none"}}>
                    <div className="loading"><SvgLoading /></div>
            </div>
            <Header/>
            {/* {this.state.locationData && this.state.locationData.location? (<div>
                {this.state.locationData.location ? <Header showLogo={true} showLocationFinder={true} showSearchRestaurent={true} findLocation={()=>this.getLocation('force')} searchRestaurent={this.searchByKeyword} locationName={this.state.locationData.location.title} />: null}
                {this.state.restaurentsData && this.state.restaurentsData.restaurants && this.state.restaurentsData.restaurants.length > 0 ? (<div className="mainContainer">
                <div style={{width:'100%',display:'flex',justifyContent:'flex-end',cursor:'pointer'}}><p style={{paddingRight:'1em'}} onClick={this.rateSort}>Sort By: <span style={{color: this.state.isRateSorted ? '#099e44' : '#000'}}>Rating (High - Low)</span></p></div>
                <ul ref={this.listPaneDidMount} className="rest-tiles" style={{height:this.renderListHeight(),overflow:'scroll'}}>
                    {this.state.restaurentsData.restaurants.map((item,id)=>this.renderRestaurents(item,id))}
                </ul>
                </div>): <p>No Restaurants found...!</p>}
                {this.props.homeApis.fetchedLocationDataSuccess && !this.state.restaurentsData.restaurants ? this.getEndOfListMarkup() : null}
            </div>):<p className="startError">Please enable location to populate results</p>} */}
        </div>)
    }
}

function mapStateToProps(state) {
    return {
        homeApis: state.homeApis
    };
}
export default connect(mapStateToProps)(Home);