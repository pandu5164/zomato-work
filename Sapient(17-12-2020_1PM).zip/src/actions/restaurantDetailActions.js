import actions from './index';
import constants from '../constants';
import urls from '../urls';
import {commonHeaders, checkHttpStatus, fetch_retry} from '../utils';

// export function getRestaurantDetails(data){
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_RESTAURENT_DETAIL,
//         });
//         let customizedHeaders = {...commonHeaders}
//         let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_DETAIL + '?';
//         let params = {res_id: data};
//         let queryParams = Object.keys(params)
//             .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
//             .join('&');
//         let finalUrl = url + queryParams;
//         return fetch_retry(()=>{
//             return fetch(finalUrl , {
//                 method: 'GET',
//                 headers: customizedHeaders,
//             }).then(checkHttpStatus)
//             .then(response=>{
//                 dispatch({
//                     type:actions.GET_RESTAURENT_DETAIL_SUCCESS,
//                     data: response
//                 })
//             })
//             .catch(error=>{
//                 dispatch({
//                     type:actions.GET_RESTAURENT_DETAIL_FAILURE,
//                     errorMessage: error
//                 })
//             })
//         })
//     }
// }

// export function getRestaurantDetail(data) {
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_RESTAURENT_DETAIL,
//         });
//         let customizedHeaders = {...commonHeaders}
//         let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_DETAIL + '?';
//         let params = {res_id: data};
//         let queryParams = Object.keys(params)
//             .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
//             .join('&');
//         let finalUrl = url + queryParams;
//         return fetch(finalUrl , {
//             method: 'GET',
//             headers: customizedHeaders,
//         }).then(checkHttpStatus)
//         .then(response=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DETAIL_SUCCESS,
//                 data: response
//             })
//         })
//         .catch(error=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_DETAIL_FAILURE,
//                 errorMessage: error
//             })
//         })
//     }
// };

// export function getRestaurantReviews(data) {
//     return function (dispatch, getState) {
//         // const state = getState();
//         dispatch({
//             type: actions.GET_RESTAURENT_REVIEW,
//         });
//         let customizedHeaders = {...commonHeaders}
//         // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_REVIEW + '?res_id='+data.id;
//         // if(data.start){
//         //     url += '&start='+data.start;
//         // }
//         // if(data.count){
//         //     url += '&count='+data.count;
//         // }
//         let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_REVIEW + '?';
//         let finalUrl = url + new URLSearchParams({
//             res_id: data.id,
//             start: data.start,
//             count: data.count,
//         });
//         return fetch(finalUrl, {
//             method: 'GET',
//             headers: customizedHeaders,
//         }).then(checkHttpStatus)
//         .then(response=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_REVIEW_SUCCESS,
//                 data: response
//             })
//         })
//         .catch(error=>{
//             dispatch({
//                 type:actions.GET_RESTAURENT_REVIEW_FAILURE,
//                 errorMessage: error
//             })
//         })
//     }
// };