import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import homeApis from './homeReducer';
import restaurentDetailApis from './restaurantDetailReducer';
export default combineReducers({
    routing: routerReducer,
    homeApis,
    // restaurentDetailApis
});