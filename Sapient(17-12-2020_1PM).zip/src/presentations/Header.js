import React from 'react';
import constants from '../constants';
import LazyLoad from 'react-lazy-load';
import logo from '../assets/images/sapient.png';
// import location from '../assets/images/location.png'
export default function Header(props) {
    return(<div>
        <p><b>SpacEx Launch Program</b></p>
    </div>);
    // return(<div className="header-zomato">
    //     {props.showLogo ? (<div style={{paddingLeft:'1em'}}>
    //     <LazyLoad height={'auto'} offset={500} once>
    //         <img className={`logoImg`} width="75"
    //             alt={'Zomato'}
    //             src={logo}
    //         />
    //     </LazyLoad>
    //     </div>):null}
    //     {props.showSearchRestaurent ? (<div>
    //         <input type="text" onChange={props.searchRestaurent} placeholder="Search for Restaurants"/>
    //     </div>):null}
    //     {props.showLocationFinder ? (<div className="locationArea" onClick={props.findLocation} style={{cursor:'pointer',paddingRight:'1em',display:'flex',alignItems:'center'}}>
    //         <p style={{paddingRight:'5px'}}>{props.locationName}</p>
    //         <span>
    //             {/* <LazyLoad height={15} offset={500} once>
    //                 <img className={`locationImg`} width="15"
    //                     alt={'Locate'}
    //                     src={location}
    //                     style={{background:'#fff',borderRadius:'10px'}}
    //                 />
    //             </LazyLoad> */}
    //         </span>
    //     </div>) : null}
    // </div>);
};