(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./src/actions/homeActions.js":
/*!************************************!*\
  !*** ./src/actions/homeActions.js ***!
  \************************************/
/*! exports provided: getLaunchData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLaunchData", function() { return getLaunchData; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ "./src/actions/index.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _urls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../urls */ "./src/urls.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils */ "./src/utils.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





function getLaunchData(stateData) {
  return function (dispatch, getState) {
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA
    });
    var url = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].base_api_url + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].api_point + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_LAUNCH_DETAILS;
    url += '?limit=' + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].list_max;

    if (stateData) {
      if (stateData.is_successful_launch) {
        if (stateData.is_successful_launch == 'true') {
          url += '&launch_success=' + stateData.is_successful_launch;
        } else {
          url += '&launch_success=' + stateData.is_successful_launch;
        }
      }

      if (stateData.is_successful_land) {
        if (stateData.is_successful_land == 'true') {
          url += '&land_success=' + stateData.is_successful_land;
        } else {
          url += '&land_success=' + stateData.is_successful_land;
        }
      }

      if (stateData.selected_launch) {
        url += '&launch_year=' + stateData.selected_launch;
      }
    } // let vIndx = url.indexOf('v3');
    // let redirectUrl = url.substring(vIndx);


    return fetch(url, {
      method: 'GET',
      headers: _objectSpread(_objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]), {}, {
        accept: '*'
      })
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      // dispatch(push('/'+redirectUrl));
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA_FAILURE,
        errorMessage: error
      });
    });
  };
}

/***/ }),

/***/ "./src/assets/images/sapient.png":
/*!***************************************!*\
  !*** ./src/assets/images/sapient.png ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "804308cb758b9f3fa3cfcc6bbe2ef9b8.png");

/***/ }),

/***/ "./src/components/Home.js":
/*!********************************!*\
  !*** ./src/components/Home.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router-redux */ "./node_modules/react-router-redux/lib/index.js");
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_router_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-waypoint */ "./node_modules/react-waypoint/es/index.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils */ "./src/utils.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _presentations_Header__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../presentations/Header */ "./src/presentations/Header.js");
/* harmony import */ var _presentations_Footer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../presentations/Footer */ "./src/presentations/Footer.js");
/* harmony import */ var _actions_homeActions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../actions/homeActions */ "./src/actions/homeActions.js");
/* harmony import */ var _presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../presentations/SvgLoading */ "./src/presentations/SvgLoading.js");
/* harmony import */ var _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../assets/images/sapient.png */ "./src/assets/images/sapient.png");








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }














var Home = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Home, _Component);

  var _super = _createSuper(Home);

  function Home(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Home);

    _this = _super.call(this, props);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleThumbnailLoadError", function (event) {
      event.target.src = _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_18__["default"];
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "isLaunched", function (event) {
      _this.setState({
        is_successful_launch: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "isLanded", function (event) {
      _this.setState({
        is_successful_land: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "selectedYear", function (event) {
      _this.setState({
        selected_launch: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "listPaneDidMount", function (node) {
      if (node) {
        node.addEventListener('scroll', _this.handleListScroll);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleListScroll", function (event) {
      var node = event.target;
      var bottom = node.scrollHeight - node.scrollTop === node.clientHeight;

      if (bottom) {
        // console.log('BOTTOM REACHED:', bottom);
        _this.fetchMoreCards();
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "fetchMoreCards", function () {
      var total_item_count = _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_max; //this.props.homeApis.searchRestaurentsResultData.results_found;

      var current_number = _this.props.homeApis.launch_data && _this.props.homeApis.launch_data.length ? _this.props.homeApis.launch_data.length : 0;

      if (!_this.props.homeApis.searching_failed && (!totalItemCount || totalItemCount > _this.props.homeApis.launch_data.length)) {
        var temp_state = Object.assign({}, _this.state);
        temp_state.start_count = current_number;

        _this.setState(temp_state);
      }
    });

    _this.state = {
      codeBy: 'Pavan Kumar Z',
      total_results: _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_max,
      start_count: 0,
      launch_year: [2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020],
      is_successful_launch: null,
      is_successful_land: null,
      selected_launch: null,
      launch_values: ['true', 'false'],
      land_values: ['true', 'false']
    };
    _this.listPaneDidMount = _this.listPaneDidMount.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.handleListScroll = _this.handleListScroll.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.fetchMoreCards = Object(_utils__WEBPACK_IMPORTED_MODULE_12__["debounce"])(_this.fetchMoreCards, 500, _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.isLanded = _this.isLanded.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.isLaunched = _this.isLaunched.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.selectedYear = _this.selectedYear.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Home, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      if (this.props.location && this.props.location.query) {
        var launch_year = this.props.location.query.launch_year;
        var launch_success = this.props.location.query.launch_success;
        var land_success = this.props.location.query.land_success;
        this.setState({
          selected_launch: launch_year,
          is_successful_land: land_success,
          is_successful_launch: launch_success
        });
      }

      setTimeout(function () {
        _this2.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this2.state));
      }, 0);
    }
  }, {
    key: "renderData",
    value: function renderData(item, id) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
        key: id
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default.a, {
        height: 75,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        className: "rocketImg",
        alt: 'Restaurent Logo',
        src: item.links.mission_patch_small,
        onError: this.handleThumbnailLoadError
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, item.mission_name, " #", item.flight_number), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Mission Ids:")), item.mission_id && item.mission_id.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        className: "mission_id"
      }, item.mission_id.map(function (mis, i) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
          key: i
        }, mis, i == item.mission_id.length - 1 ? '.' : ', ');
      })) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, "N.A"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Launch Year:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, item.launch_year)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Successful Launch: "), item.launch_success ? 'True' : 'False'), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Successful Landing: "), item.rocket.first_stage.cores[0].land_success ? 'True' : 'False'));
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "overlay",
        style: {
          display: this.props.homeApis.launchdata_searching ? "block" : "none"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "loading"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_17__["default"], null))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Header__WEBPACK_IMPORTED_MODULE_14__["default"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "left-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-data"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", null, "Filters"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Launch Year"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.launch_year.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id,
          style: {
            float: id == _this3.state.launch_year.length - 1 ? 'left' : 'none',
            width: id == _this3.state.launch_year.length - 1 ? '100%' : 'auto',
            paddingLeft: id == _this3.state.launch_year.length - 1 ? '5px' : '0'
          }
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "item"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.selectedYear(event);
          },
          name: "item",
          checked: item == _this3.state.selected_launch,
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, item)));
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Successful Launch"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.launch_values.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "launch"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.isLaunched(event);
          },
          checked: item == _this3.state.is_successful_launch,
          name: "launch",
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, id == 0 ? 'True' : 'False')));
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Successful Landing"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.land_values.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "land"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.isLanded(event);
          },
          checked: item == _this3.state.is_successful_land,
          name: "land",
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, id == 0 ? 'True' : 'False')));
      }))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "right-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-data"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        ref: this.listPaneDidMount,
        className: "rest-tiles"
        /*style={{ height: this.renderListHeight(), overflow: 'scroll' }}*/

      }, this.props.homeApis.launch_data.length ? this.props.homeApis.launch_data.map(function (item, id) {
        return _this3.renderData(item, id);
      }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "No Data Available"))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Footer__WEBPACK_IMPORTED_MODULE_15__["default"], {
        developer: this.state.codeBy
      }));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      // for componentReceiveProps
      // console.log(props);
      if (props.homeApis.launchdata_searching_success && props.homeApis.launch_data) {
        //props.homeApis.fetchingLocationData &&
        // this.setState({locationData : props.homeApis.fetchedLocationData});
        state.launch_data = props.homeApis.launch_data;
      }

      return state;
    }
  }]);

  return Home;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

function mapStateToProps(state) {
  return {
    homeApis: state.homeApis
  };
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(mapStateToProps)(Home));

/***/ }),

/***/ "./src/presentations/Footer.js":
/*!*************************************!*\
  !*** ./src/presentations/Footer.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Footer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function Footer(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("footer", {
    className: "space-footer"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("b", null, "Developed by: ", props.developer));
}

/***/ }),

/***/ "./src/presentations/Header.js":
/*!*************************************!*\
  !*** ./src/presentations/Header.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Header; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function Header(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("header", {
    className: "space-header"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("b", null, "SpacEx Launch Program"));
}
;

/***/ }),

/***/ "./src/presentations/SvgLoading.js":
/*!*****************************************!*\
  !*** ./src/presentations/SvgLoading.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SvgLoading; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.js");


function SvgLoading(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
    width: "72px",
    height: "72px",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 100 100",
    preserveAspectRatio: "xMidYMid",
    className: "uil-ring"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("rect", {
    x: "0",
    y: "0",
    width: "100",
    height: "100",
    fill: "none",
    className: "bk"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("circle", {
    cx: "50",
    cy: "50",
    r: "45",
    strokeDasharray: "183.7831702350029 98.96016858807849",
    stroke: _constants__WEBPACK_IMPORTED_MODULE_1__["default"].COLORS.SCARLET,
    fill: "none",
    strokeWidth: "10"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("animateTransform", {
    attributeName: "transform",
    type: "rotate",
    values: "0 50 50;180 50 50;360 50 50;",
    keyTimes: "0;0.5;1",
    dur: "1s",
    repeatCount: "indefinite",
    begin: "0s"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
    className: "pumpkin-orange",
    style: {
      marginTop: '0.7em'
    }
  }, "Loading"));
}

/***/ }),

/***/ "./src/urls.js":
/*!*********************!*\
  !*** ./src/urls.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  GET_LAUNCH_DETAILS: '/launches'
});

/***/ }),

/***/ "./src/utils.js":
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/*! exports provided: commonHeaders, checkHttpStatus, debounce, fetch_retry */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commonHeaders", function() { return commonHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkHttpStatus", function() { return checkHttpStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "debounce", function() { return debounce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetch_retry", function() { return fetch_retry; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./src/constants.js");



var commonHeaders = {
  Accept: 'application/json',
  'Content-Type': 'application/json; charset=UTF-8',
  'user-key': _constants__WEBPACK_IMPORTED_MODULE_2__["default"].zomatoPublicKey
};
function checkHttpStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response.json();
  } else {
    var error = new Error(response.statusText);
    error.response = response;
    throw error;
  }
}
;
function debounce(func, wait, context) {
  var timeout, args, timestamp, result;

  var later = function later() {
    var last = Date.now() - timestamp;

    if (last < wait && last >= 0) {
      timeout = setTimeout(later, wait - last);
    } else {
      timeout = null;
      result = func.apply(context, args);
      args = null;
    }
  };

  return function () {
    args = arguments;
    timestamp = Date.now();

    if (!timeout) {
      timeout = setTimeout(later, wait);
    }

    return result;
  };
}
;
var fetch_retry = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(fetch, retryAttempt, retryAfter) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return fetch();

          case 3:
            return _context.abrupt("return", _context.sent);

          case 6:
            _context.prev = 6;
            _context.t0 = _context["catch"](0);

            if (!(retryAttempt <= 1)) {
              _context.next = 10;
              break;
            }

            throw _context.t0;

          case 10:
            _context.next = 12;
            return new Promise(function (resolve) {
              var timeout = retryAfter;

              if (timeout === undefined || timeout === null) {
                timeout = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].FETCH_RETRY_TIMEOUT_IN_SECONDS;
              }

              setTimeout(resolve, timeout * 1000);
            }).then(function () {
              return fetch_retry(fetch, retryAttempt - 1, retryAfter);
            });

          case 12:
            return _context.abrupt("return", _context.sent);

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 6]]);
  }));

  return function fetch_retry(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

/***/ })

}]);