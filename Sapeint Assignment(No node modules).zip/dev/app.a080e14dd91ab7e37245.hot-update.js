webpackHotUpdate("app",{

/***/ "./src/routes.js":
/*!***********************!*\
  !*** ./src/routes.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/es/index.js");
/* harmony import */ var _components_App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/App */ "./src/components/App.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ "./src/constants.js");




/* harmony default export */ __webpack_exports__["default"] = (function () {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router__WEBPACK_IMPORTED_MODULE_1__["Route"], {
    path: "/",
    component: _components_App__WEBPACK_IMPORTED_MODULE_2__["default"]
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router__WEBPACK_IMPORTED_MODULE_1__["IndexRoute"], {
    getComponent: function getComponent(location, cb) {
      __webpack_require__.e(/*! require.ensure */ 3).then((function (require) {
        cb(null, __webpack_require__(/*! ./components/Home */ "./src/components/Home.js").default);
      }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router__WEBPACK_IMPORTED_MODULE_1__["Route"], {
    path: "".concat(_constants__WEBPACK_IMPORTED_MODULE_3__["default"].api_point, "/launches"),
    getComponent: function getComponent(location, cb) {
      __webpack_require__.e(/*! require.ensure */ 3).then((function (require) {
        cb(null, __webpack_require__(/*! ./components/Home */ "./src/components/Home.js").default);
      }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
    }
  }));
});

/***/ })

})