webpackHotUpdate("app",{

/***/ "./src/reducers/homeReducer.js":
/*!*************************************!*\
  !*** ./src/reducers/homeReducer.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return homeApis; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _actions_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/index */ "./src/actions/index.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }


var initialState = {
  error: null,
  launch_data: [],
  launchdata_searching_failed: false,
  launchdata_searching_success: false,
  launchdata_searching: false //  fetchingLocationData: false,
  //  fetchedLocationDataSuccess: false,
  //  fetchedLocationDataFailure: false,
  //  fetchedLocationData: null,
  //  searchingRestaurents: false,
  //  searchingRestaurentsSuccess: null,
  //  searchingRestaurentsFailure: null,
  //  searchRestaurentsResultData: {}

};
function homeApis() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case _actions_index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA:
      {
        var tempObj = {
          launchdata_searching: true,
          launchdata_searching_failed: false,
          launchdata_searching_success: false,
          error: false
        };
        return _objectSpread(_objectSpread({}, state), tempObj);
      }

    case _actions_index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA_SUCCESS:
      {
        var _tempObj = {
          launchdata_searching: false,
          launchdata_searching_failed: false,
          launchdata_searching_success: true,
          launch_data: action.data
        };
        return _objectSpread(_objectSpread({}, state), _tempObj);
      }

    case _actions_index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LAUNCH_DATA_FAILURE:
      {
        var _tempObj2 = {
          launchdata_searching: false,
          launchdata_searching_failed: true,
          launchdata_searching_success: false,
          error: action.errorMessage
        };
        return _objectSpread(_objectSpread({}, state), _tempObj2);
      }
    // case actions.GET_LOCATION_DATA:{
    //     // return Object.assign({}, state, {
    //     let tempObj={
    //         fetchingLocationData: true,
    //         fetchedLocationDataSuccess: false,
    //         fetchedLocationDataFailure: false,
    //         fetchedLocationData: null
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_LOCATION_DATA_SUCCESS: {
    //     // return Object.assign({}, state, {
    //     let tempObj={
    //         fetchingLocationData: false,
    //         fetchedLocationDataSuccess: true,
    //         fetchedLocationDataFailure: false,
    //         fetchedLocationData: action.data
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_LOCATION_DATA_FAILURE:{
    //     // return Object.assign({}, state, {
    //     let tempObj={  
    //         fetchingLocationData: false,
    //         fetchedLocationDataSuccess: false,
    //         fetchedLocationDataFailure: true,
    //         fetchLocationError: action.errorMessage
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_RESTAURENT_SEARCH_DATA: {
    //     // return Object.assign({}, state, {
    //     let tempObj={  
    //         searchingRestaurents: true,
    //         searchingRestaurentsSuccess: false,
    //         searchingRestaurentsFailure: false,
    //         searchRestaurentsResultData: null
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_RESTAURENT_DATA: {
    //     // return Object.assign({}, state, {
    //     let tempObj={
    //         searchingRestaurents: true,
    //         searchingRestaurentsSuccess: false,
    //         searchingRestaurentsFailure: false,
    //         searchRestaurentsResultData: action.isReset ? null : state.searchRestaurentsResultData
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_RESTAURENT_DATA_SUCCESS: {
    //     let orderList = [];
    //     if (state.searchRestaurentsResultData && state.searchRestaurentsResultData.restaurants) {
    //         orderList = [...state.searchRestaurentsResultData.restaurants,...action.data.restaurants]//state.searchRestaurentsResultData.restaurants.concat(action.data.restaurants);
    //         action.data.restaurants = orderList;
    //     } else if (state.searchRestaurentsResultData && state.searchRestaurentsResultData.restaurants) {
    //         orderList = action.data.restaurants;
    //         action.data.restaurants = orderList;
    //     }
    //     // return Object.assign({}, state, {
    //     let tempObj={
    //         searchingRestaurents: false,
    //         searchingRestaurentsSuccess: true,
    //         searchingRestaurentsFailure: false,
    //         searchRestaurentsResultData: action.data
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }
    // case actions.GET_RESTAURENT_DATA_FAILURE: {
    //     // return Object.assign({}, state, {
    //     let tempObj={
    //         searchingRestaurents: false,
    //         searchingRestaurentsSuccess: false,
    //         searchingRestaurentsFailure: true,
    //         error: action.errorMessage
    //     }
    //     // });
    //     return {...state,...tempObj};
    // }

    default:
      {
        return state;
      }
  }
}

/***/ })

})