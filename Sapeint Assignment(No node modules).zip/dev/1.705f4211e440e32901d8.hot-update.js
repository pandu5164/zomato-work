webpackHotUpdate(1,{

/***/ "./src/presentations/Footer.js":
/*!*************************************!*\
  !*** ./src/presentations/Footer.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: /Users/pavan/sapeint/src/presentations/Footer.js: Expected corresponding JSX closing tag for <footer> (9:8)\n\n\u001b[0m \u001b[90m  7 | \u001b[39m    \u001b[36mreturn\u001b[39m(\u001b[33m<\u001b[39m\u001b[33mfooter\u001b[39m className\u001b[33m=\u001b[39m\u001b[32m\"space-header\"\u001b[39m\u001b[33m>\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m  8 | \u001b[39m        \u001b[33m<\u001b[39m\u001b[33mb\u001b[39m\u001b[33m>\u001b[39m\u001b[33mDeveloped\u001b[39m by\u001b[33m:\u001b[39m {props\u001b[33m.\u001b[39mdeveloper}\u001b[33m<\u001b[39m\u001b[33m/\u001b[39m\u001b[33mb\u001b[39m\u001b[33m>\u001b[39m\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m  9 | \u001b[39m        \u001b[33m<\u001b[39m\u001b[33m/\u001b[39m\u001b[33mheader\u001b[39m\u001b[33m>\u001b[39m)\u001b[33m;\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m    | \u001b[39m        \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 10 | \u001b[39m}\u001b[0m\n\u001b[0m \u001b[90m 11 | \u001b[39m\u001b[0m\n    at Object._raise (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:766:17)\n    at Object.raiseWithData (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:759:17)\n    at Object.raise (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:753:17)\n    at Object.jsxParseElementAt (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:4680:16)\n    at Object.jsxParseElement (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:4706:17)\n    at Object.parseExprAtom (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:4713:19)\n    at Object.parseExprSubscripts (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:9844:23)\n    at Object.parseUpdate (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:9824:21)\n    at Object.parseMaybeUnary (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:9813:17)\n    at Object.parseExprOps (/Users/pavan/sapeint/node_modules/@babel/parser/lib/index.js:9683:23)");

/***/ })

})