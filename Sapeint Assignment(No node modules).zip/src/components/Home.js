import React, { Component } from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { Waypoint } from 'react-waypoint';
import LazyLoad from 'react-lazy-load';
import { debounce } from '../utils';
import constants from '../constants'
import Header from '../presentations/Header';
import Footer from '../presentations/Footer';
import {getLaunchData} from '../actions/homeActions';
import SvgLoading from '../presentations/SvgLoading';
import DefaultProductThumbnailIcon from '../assets/images/sapient.png';
class Home extends Component {
    constructor(props) {
        super(props);
        this.state={
            codeBy: 'Pavan Kumar Z',
            total_results: constants.list_max,
            start_count: 0,
            launch_year: [2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020],
            is_successful_launch: null,
            is_successful_land: null,
            selected_launch:null,
            launch_values:['true','false'],
            land_values:['true','false']
        }
        this.listPaneDidMount = this.listPaneDidMount.bind(this);
        this.handleListScroll = this.handleListScroll.bind(this);
        this.fetchMoreCards = debounce(this.fetchMoreCards, 500, this);
        this.isLanded = this.isLanded.bind(this);
        this.isLaunched = this.isLaunched.bind(this);
        this.selectedYear = this.selectedYear.bind(this);
    }
     componentDidMount(){
         if(this.props.location && this.props.location.query){
            let launch_year = this.props.location.query.launch_year;
            let launch_success = this.props.location.query.launch_success;
            let land_success = this.props.location.query.land_success;
            this.setState({selected_launch:launch_year,is_successful_land:land_success,is_successful_launch:launch_success});
         }
         setTimeout(()=>{
            this.props.dispatch(getLaunchData(this.state));
         },0);
    }
    static getDerivedStateFromProps(props,state){ // for componentReceiveProps
        // console.log(props);
        if(props.homeApis.launchdata_searching_success && props.homeApis.launch_data){ //props.homeApis.fetchingLocationData &&
        // this.setState({locationData : props.homeApis.fetchedLocationData});
            state.launch_data = props.homeApis.launch_data;
        }
        return state;
    }
    handleThumbnailLoadError=(event)=>{
        event.target.src = DefaultProductThumbnailIcon;
    }
    isLaunched=(event)=>{
        this.setState({is_successful_launch:event.target.value});
        setTimeout(()=>{
            this.props.dispatch(push('/v3/launches?limit=100' + (this.state.is_successful_launch ? '&launch_success='+this.state.is_successful_launch : '') + (this.state.is_successful_land ? '&land_success='+this.state.is_successful_land : '') + (this.state.selected_launch ? '&launch_year='+this.state.selected_launch : '') ));
            this.props.dispatch(getLaunchData(this.state))
        })
    }
    isLanded=(event)=>{
        this.setState({is_successful_land:event.target.value});
        setTimeout(()=>{
            this.props.dispatch(push('/v3/launches?limit=100' + (this.state.is_successful_launch ? '&launch_success='+this.state.is_successful_launch : '') + (this.state.is_successful_land ? '&land_success='+this.state.is_successful_land : '') + (this.state.selected_launch ? '&launch_year='+this.state.selected_launch : '') ));
            this.props.dispatch(getLaunchData(this.state))
        })
    }
    selectedYear=(event)=>{
        this.setState({selected_launch:event.target.value});
        setTimeout(()=>{
            this.props.dispatch(push('/v3/launches?limit=100' + (this.state.is_successful_launch ? '&launch_success='+this.state.is_successful_launch : '') + (this.state.is_successful_land ? '&land_success='+this.state.is_successful_land : '') + (this.state.selected_launch ? '&launch_year='+this.state.selected_launch : '') ));
            this.props.dispatch(getLaunchData(this.state))
        })
    }
     listPaneDidMount = (node) => {
        if (node) {
            node.addEventListener('scroll', this.handleListScroll);
        }
    };
    handleListScroll=(event)=>{
        var node = event.target;
        const bottom = node.scrollHeight - node.scrollTop === node.clientHeight;
        if (bottom) {
            // console.log('BOTTOM REACHED:', bottom);
            this.fetchMoreCards();
        }
    }
    fetchMoreCards = () => {
        const total_item_count = constants.list_max;//this.props.homeApis.searchRestaurentsResultData.results_found;
        let current_number = this.props.homeApis.launch_data && this.props.homeApis.launch_data.length ? this.props.homeApis.launch_data.length : 0;
        if (
            !this.props.homeApis.searching_failed &&
            (!totalItemCount || totalItemCount > this.props.homeApis.launch_data.length)
        ) {
            let temp_state = Object.assign({}, this.state);
            temp_state.start_count = current_number;   
            this.setState(temp_state);
        }
    }
    renderData(item,id){
        return(<li key={id}>
            <LazyLoad height={75} offset={500} once>
                <img className={`rocketImg`}
                    alt={'Restaurent Logo'}
                    src={item.links.mission_patch_small}
                    onError={this.handleThumbnailLoadError}
                />
            </LazyLoad>
            <p>{item.mission_name} #{item.flight_number}</p>
            <p><b>Mission Ids:</b></p>
            {item.mission_id && item.mission_id.length ? (<ul className="mission_id">
            {item.mission_id.map((mis,i)=>(<li key={i}>{mis}{i == item.mission_id.length -1 ? '.':', '}</li>))}
            </ul>):<p>N.A</p>}
            <p><b>Launch Year:</b><span>{item.launch_year}</span></p>
            <p><b>Successful Launch: </b>{item.launch_success ? 'True' : 'False'}</p>
            <p><b>Successful Landing: </b>{item.rocket.first_stage.cores[0].land_success ? 'True' : 'False'}</p>
        </li>);
    }
    render(){
        return (<div>
            <div className="overlay" style={{display: (this.props.homeApis.launchdata_searching) ? "block" : "none"}}>
                    <div className="loading"><SvgLoading /></div>
            </div>
            <Header/>
            <section className="launch-container">
                <div className="left-container">
                    <section className="launch-data">
                        <h1>Filters</h1>
                        <h3>Launch Year</h3>
                        <hr/>
                        <div className="container">
                            <div className="radio-toolbar">
                                {this.state.launch_year.map((item, id) => (<div key={id} style={{float: id == this.state.launch_year.length -1 ? 'left' : 'none',width:id == this.state.launch_year.length -1 ? '100%':'auto',paddingLeft:id == this.state.launch_year.length -1 ? '5px':'0'}}>
                                    <label htmlFor="item" >
                                        <input type="radio" onChange={(event)=>this.selectedYear(event)} name="item" checked={item == this.state.selected_launch} value={item}></input>
                                        <span>{item}</span>
                                    </label>
                                </div>))}
                            </div>
                        </div>
                        <h3>Successful Launch</h3>
                        <hr />
                        <div className="container">
                            <div className="radio-toolbar">
                            {this.state.launch_values.map((item,id)=>(<div key={id}>
                                <label htmlFor="launch">
                                <input type="radio" onChange={(event)=>this.isLaunched(event)} checked={item == this.state.is_successful_launch} name="launch" value={item}></input>
                                <span>{id == 0 ? 'True' : 'False'}</span>
                            </label>
                            </div>))}
                            </div>
                        </div>
                        <h3>Successful Landing</h3>
                        <hr />
                        <div className="container">
                            <div className="radio-toolbar">
                            {this.state.land_values.map((item,id)=>(<div key={id}>
                                <label htmlFor="land">
                                <input type="radio" onChange={(event)=>this.isLanded(event)} checked={item == this.state.is_successful_land} name="land" value={item}></input>
                                <span>{id == 0 ? 'True' : 'False'}</span>
                            </label>
                            </div>))}
                            </div>
                        </div>
                    </section>
                </div>
                {/* filter section ends*/}
                <div className="right-container">
                    <section className="launch-data">
                    {/* <h2>LaunchData</h2> */}
                        <ul ref={this.listPaneDidMount} className="rest-tiles" /*style={{ height: this.renderListHeight(), overflow: 'scroll' }}*/ >
                            {this.props.homeApis.launch_data.length ? this.props.homeApis.launch_data.map((item, id) => this.renderData(item, id)) : <h2>No Data Available</h2>}
                        </ul>
                    </section>
                </div>
                {/* launch data ends*/}
            </section>
            <Footer developer={this.state.codeBy} />
        </div>)
    }
}

function mapStateToProps(state) {
    return {
        homeApis: state.homeApis
    };
}
export default connect(mapStateToProps)(Home);