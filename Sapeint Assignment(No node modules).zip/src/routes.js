import React from 'react';
import { IndexRoute, Route } from 'react-router';
import App from './components/App';
import constants from './constants';
export default () => {
    return (
        <Route path="/" component={App}>
            <IndexRoute
                getComponent={(location, cb) => {
                    require.ensure([], require => {
                        cb(null, require('./components/Home').default);
                    });
                }}
            />
            <Route
                path={`${constants.api_point}/launches`}
                getComponent={(location, cb) => {
                    require.ensure([], require => {
                        cb(null, require('./components/Home').default);
                    });
                }}
            />
        </Route>
    )
}