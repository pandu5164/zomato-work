export default {
    GET_LAUNCH_DETAILS: '/launches',
}