import actions from './index';
import constants from '../constants';
import urls from '../urls';
import {commonHeaders, checkHttpStatus} from '../utils';

export function getLocationData(lat,long) {
    return function (dispatch, getState) {
        const state = getState();
        dispatch({
            type: actions.GET_LOCATION_DATA,
        });
        let customizedHeaders = {...commonHeaders}
        return fetch(constants.BASE_API_URL + constants.apiPoint + urls.GET_CITY_BY_LOCATION + '?lat='+lat+'&lon='+long , {
            method: 'GET',
            headers: customizedHeaders,
        }).then(checkHttpStatus)
        .then(response=>{
            dispatch({
                type:actions.GET_LOCATION_DATA_SUCCESS,
                data: response
            })
        })
        .catch(error=>{
            dispatch({
                type:actions.GET_LOCATION_DATA_FAILURE,
                errorMessage: error
            })
        })
    }
};

export function getRestaurentData(data) {
    return function (dispatch, getState) {
        const state = getState();
        dispatch({
            type: actions.GET_RESTAURENT_DATA,
            isReset: data.isForceRefreshList ? true : false
        });
        let customizedHeaders = {...commonHeaders}
        let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
        if(data.searchword){
            url += '&q='+data.searchword;
        }
        if(data.count){
            url += '&count='+data.count;
        }
        if(data.lat){
            url += '&lat='+data.lat;
        }
        if(data.lon){
            url += '&lon='+data.lon;
        }
        if(data.start){
            url += '&start='+data.start;
        }
        if(data.radius){
            url += '&radius='+data.radius;
        }
        if(data.sort){
            url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
        } else {
            url += '&sort=real_distance';
        }
        if(data.order){
            url += data.order ? '&order='+data.order : '&order=desc';
        } else {
            url += '&order=desc';
        }
        return fetch(url , {
            method: 'GET',
            headers: customizedHeaders,
        }).then(checkHttpStatus)
        .then(response=>{
            dispatch({
                type:actions.GET_RESTAURENT_DATA_SUCCESS,
                data: response
            })
        })
        .catch(error=>{
            dispatch({
                type:actions.GET_RESTAURENT_DATA_FAILURE,
                errorMessage: error
            })
        })
    }
};

export function searchRestaurentData(data){
    return function (dispatch, getState) {
        const state = getState();
        dispatch({
            type: actions.GET_RESTAURENT_SEARCH_DATA,
        });
        let customizedHeaders = {...commonHeaders}
        let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
        if(data.searchword){
            url += '&q='+data.searchword;
        }
        if(data.count){
            url += '&count='+data.count;
        }
        if(data.lat){
            url += '&lat='+data.lat;
        }
        if(data.lon){
            url += '&lon='+data.lon;
        }
        if(data.start){
            url += '&start='+data.start;
        }
        if(data.radius){
            url += '&radius='+data.radius;
        }
        if(data.sort){
            url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
        } else {
            url += '&sort=real_distance';
        }
        if(data.order){
            url += data.order ? '&order='+data.order : '&order=desc';
        } else {
            url += '&order=desc';
        }
        return fetch(url , {
            method: 'GET',
            headers: customizedHeaders,
        }).then(checkHttpStatus)
        .then(response=>{
            dispatch({
                type:actions.GET_RESTAURENT_DATA_SUCCESS,
                data: response
            })
        })
        .catch(error=>{
            dispatch({
                type:actions.GET_RESTAURENT_DATA_FAILURE,
                errorMessage: error
            })
        })
    }
}