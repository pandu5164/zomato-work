import constants from './constants';
export const commonHeaders = {
    Accept: 'application/json',
    'Content-Type': 'application/json; charset=UTF-8',
    'user-key': constants.zomatoPublicKey
};
export function checkHttpStatus(response) {
    if (response.status >= 200 && response.status < 300) {
        return response.json();
    } else {
        var error = new Error(response.statusText);
        error.response = response;
        throw error;
    }
};
export function debounce(func, wait, context) {
    var timeout, args, timestamp, result;

    var later = function() {
        var last = Date.now() - timestamp;
        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            result = func.apply(context, args);
            args = null;
        }
    };

    return function() {
        args = arguments;
        timestamp = Date.now();
        if (!timeout) {
            timeout = setTimeout(later, wait);
        }
        return result;
    };
};