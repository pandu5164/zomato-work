import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { Router, useRouterHistory, applyRouterMiddleware } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';
import { useScroll } from 'react-router-scroll';
import { createHistory, useBasename } from 'history';
import configureStore from './store';
import 'whatwg-fetch';
import './styles/main.scss';
import routes from './routes';
let browserHistory = useRouterHistory(createHistory)({ 
    basename: '/'
})
const store = configureStore(browserHistory, {});
const history = syncHistoryWithStore(browserHistory, store);

ReactDOM.render(
    <Provider store={store} key="provider">
        <Router history={history} render={applyRouterMiddleware(useScroll())}>
            {routes()}
        </Router>
    </Provider>,
    document.getElementById('root')
);

