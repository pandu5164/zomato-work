const constants = {
    BASE_API_URL:'https://developers.zomato.com',
    apiPoint : '/api/v2.1',
    zomatoPublicKey: '2eb74a3c6ef3eda909d00007cdf72e00',
    list_Limit: 20,
    review_Limit: 10,
    COLORS:{
        PUMPKIN_ORANGE:'#f57b02',
        HINT_OF_RED: '#F9F9F9',
        SCARLET: '#D0021B'
    }
}
export default constants;