var webpack = require("webpack");
var HtmlWebpackPlugin = require("html-webpack-plugin");
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var ManifestPlugin = require("webpack-manifest-plugin");
var ChunkManifestPlugin = require("chunk-manifest-webpack-plugin");
var workboxPlugin = require("workbox-webpack-plugin");
var cleanPlugin = require("clean-webpack-plugin");
var WebpackPwaManifest = require("webpack-pwa-manifest");
var CopyWebpackPlugin = require("copy-webpack-plugin");
var InlineChunkManifestHtmlWebpackPlugin = require("inline-chunk-manifest-html-webpack-plugin");

var dist = "dist";

module.exports = {
    devtool: "hidden-source-map",

    entry: {
        app: ["./src/index.js"],
        vendor: ["react", "react-dom"]
    },

    output: {
        path: __dirname + "/dist/",
        filename: "[name].[chunkhash].min.js",
        chunkFilename: "[id].[chunkhash].min.js",
        publicPath: "/"
    },

    resolve: {
        extensions: ["", ".js", ".jsx", ".svg"],
        modules: ["src", "node_modules"]
    },

    module: {
        loaders: [
            {
                test: /\.(scss|css)$/,
                loader: ExtractTextPlugin.extract("style", "css!sass")
            },
            {
                test: /\.jsx?$/,
                exclude: /node_modules/,
                loader: "babel"
            },
            {
                test: /\.(jpe?g|gif|png)$/i,
                loader: "url-loader?limit=10000"
            },
            {
                test: /\.json$/,
                loader: "json-loader"
            },
            {
                test: /\.ttf$/,
                loader: "url-loader?limit=10000"
            },
            {
                test: /\.svg?$/,
                loader: "svg-sprite?name=[name]_[hash]!svgo"
            }
        ]
    },

    plugins: [
        // Cleans the dist folder
        new cleanPlugin([dist]),
        new ManifestPlugin({
            basePath: "/",
            fileName: "asset-manifest.json"
        }),
        new InlineChunkManifestHtmlWebpackPlugin({
            extractManifest: false,
            manifestVariable: "webpackManifest"
        }),
        // Generates an `index.html` file with the <script> injected.
        new HtmlWebpackPlugin({
            inject: true,
            template: "index.html",
            chunksSortMode: "dependency",
            minify: {
                removeComments: true,
                collapseWhitespace: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                removeEmptyAttributes: true,
                removeStyleLinkTypeAttributes: true,
                keepClosingSlash: true,
                minifyJS: true,
                minifyCSS: true,
                minifyURLs: true
            }
        }),
        new CopyWebpackPlugin(
            [{ from: __dirname + "/libs", to: __dirname + "/dist/libs" }],
            { copyUnmodified: true }
        ),
        new webpack.DefinePlugin({
            "process.env": {
                NODE_ENV: JSON.stringify("production")
            },
            __DEVELOPMENT__: false
        }),

        new webpack.optimize.CommonsChunkPlugin({
            names: ['vendor', 'mainifest'],
            minChunks: Infinity,
            filename: "vendor.js",
            children: true
        }),
        new ExtractTextPlugin("app.[chunkhash].min.css"),
        new webpack.optimize.UglifyJsPlugin({
            compressor: {
                warnings: false
            }
        }),
        new WebpackPwaManifest({
            inject: true,
            fingerprints: true,
            ios: true,
            name: "Zomato Lite",
            short_name: "Zomato POC",
            description: "Zomato squad cast work",
            background_color: "#ffffff",
            theme_color: "#f57b02",
            start_url: "./?utm_source=web_app_manifest",
            display: "standalone", 
        }),
        // Generates service worker
        new workboxPlugin({
            globDirectory: dist,
            globPatterns: ["**/*.{html,js,css,ttf,map,png}"],
            swDest: __dirname + "/dist/zomato-service-worker.js",
            swSrc: __dirname + "/src/sw.js"
        })
    ]
};
