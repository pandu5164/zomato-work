var webpack = require('webpack');
const common = require('./webpack.common.js');
const path = require('path');
const {merge} = require('webpack-merge');
var HtmlWebpackPlugin   = require('html-webpack-plugin');
var { CleanWebpackPlugin } = require("clean-webpack-plugin");
var workboxPlugin = require("workbox-webpack-plugin");
var WebpackPwaManifest = require("webpack-pwa-manifest");
console.log('Dirname is:',__dirname);
module.exports = merge(
    {
    // devtool: 'cheap-module-eval-source-map',
    // devtool: 'hidden-source-map', //hidden-source-map // false - for production
    mode:'production',//'production', //development
    performance: {
        hints: false,
        // maxEntrypointSize: 512000,
        // maxAssetSize: 512000
    },
    entry: {
        // app: [
        //     'webpack-dev-server/client?http://localhost:8082',
        //     'webpack/hot/dev-server',
        //     './src/index.js',
        // ],
        app: './src/index.js',
        vendor: [
            'react',
            'react-dom',
        ],
    },

    output: {
        path: path.resolve(__dirname, 'dist'),//path.resolve(__dirname, 'dist'),//path.join('/dist'),//__dirname+'/dist/',//path.resolve(__dirname,'dist'),//__dirname,
        // pathinfo: true,
        filename: '[name].[hash].min.js',
        chunkFilename: "[id].[hash].min.js",
        publicPath: '/',
    },

    resolve: {
        extensions: ['*', '.js', '.jsx', '.svg'],
        modules: [
            'src',
            'node_modules',
        ],
    },

    // devServer: {
    //     contentBase: './dist'
    //     // stats: 'errors-only',
    //     // historyApiFallback: {
    //     //   index: '/'
    //     // },
    //     // host:'0.0.0.0',
    //     // port: 8082
    // },

    module: {
        rules: [
            {
                test: /\.(scss|css)$/,
                loaders: ["style-loader", "css-loader", "sass-loader"]
            }, {
                test: /\.jsx?$/,
                exclude: [/node_modules/, /.+\.config.js/],
                loader: 'babel-loader'
            }, {
                test: /\.(jpe?g|gif|png)$/i,
                loader: 'url-loader?limit=10000'
            }, {
                test: /\.json$/,
                loader: 'json-loader'
            }, {
                test: /\.ttf$/,
                loader: "url-loader?limit=10000"
            }, {
                test: /\.svg?$/,
                loader: 'svg-url-loader'
            }
        ],
    },
    optimization: {
        "minimize": false,
        "concatenateModules": false,
        "noEmitOnErrors": true,
        "namedModules": true,
        "namedChunks": true,
        "runtimeChunk": 'single', //true, 'single', false
        splitChunks: {
            cacheGroups: {
                default: {
                    chunks: 'initial', //'async','all'
                    name: 'bundle',
                    priority: -20,
                    reuseExistingChunk: true,
                },
                vendors: {
                    chunks: 'all', //'initial'
                    name: 'vendor',
                    priority: -10,
                    test: /node_modules\/(.*)\.js/
                }
            },
            minSize: 10000,
            maxSize: 250000,
        }
    },

    plugins: [
        // Generates an `index.html` file with the <script> injected.
        new CleanWebpackPlugin({
            cleanAfterEveryBuildPatterns: ['dist']
        }),
        new HtmlWebpackPlugin(
            Object.assign(
              {},
              {
                inject: true,
                template: './public/index.html',
                favicon: './public/zomato.ico'
              },
               {
                    minify: {
                      removeComments: true,
                      collapseWhitespace: true,
                      removeRedundantAttributes: true,
                      useShortDoctype: true,
                      removeEmptyAttributes: true,
                      removeStyleLinkTypeAttributes: true,
                      keepClosingSlash: true,
                      minifyJS: true,
                      minifyCSS: true,
                      minifyURLs: true,
                    },
                  }
            )
          ),
        new webpack.HotModuleReplacementPlugin(),
        
        new webpack.DefinePlugin({
            __CLIENT__: JSON.stringify(true),
            __DEVELOPMENT__: true,
            __DEVTOOLS__: true
        }),
        new WebpackPwaManifest({
            inject: true,
            fingerprints: true,
            ios: true,
        
            name: 'Zomato',
            short_name: 'ZomatoPWA',
            description: 'My Zomato Web App!',
            background_color: '#ffffff',
            crossorigin: 'use-credentials', //can be null, use-credentials or anonymous
            icons: [
              {
                src: path.resolve('src/assets/images/zomato.png'),
                sizes: [96, 128, 192, 256, 384, 512] // multiple sizes
              },
              {
                src: path.resolve('src/assets/images/zomato.png'),
                size: '1024x1024' // you can also use the specifications pattern
              },
              {
                src: path.resolve('src/assets/images/zomato.png'),
                size: '1024x1024',
                purpose: 'maskable'
              }
            ],

            theme_color: "#ffffff",
            start_url: "./?utm_source=web_app_manifest",
            display: "standalone",
            orientation: "portrait",
            related_applications: [
                {
                    platform: "play",
                    id: "com.zomato"
                }
            ],

        }),
        // new workboxPlugin.GenerateSW({
        //     additionalManifestEntries: ["**/*.{html,js,css,ttf,map,png,jpg,svg}"]
        //     manifestTransforms: [
        //     addTemplatedURLs({
        //         "Index": ["/src/sw.js"]
        //     })
        //     ],
        //     clientsClaim: true,
        //     skipWaiting: true,
        // }),

        // new workboxPlugin.InjectManifest({
        //     // globDirectory: 'dist',
        //     // globPatterns: ["**/*.{html,js,css,ttf,map,png,jpg,svg}"],
        //     // swDest: __dirname + "/dist/hng-service-worker.js",
        //     // swSrc: __dirname + "/src/sw.js"
        // })
    ]
}
);
