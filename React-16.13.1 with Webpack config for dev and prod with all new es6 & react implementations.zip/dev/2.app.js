(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./src/actions/homeActions.js":
/*!************************************!*\
  !*** ./src/actions/homeActions.js ***!
  \************************************/
/*! exports provided: getLocationData, getRestaurentData, searchRestaurentData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocationData", function() { return getLocationData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRestaurentData", function() { return getRestaurentData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchRestaurentData", function() { return searchRestaurentData; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ "./src/actions/index.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _urls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../urls */ "./src/urls.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils */ "./src/utils.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





function getLocationData(lat, long) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LOCATION_DATA
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]);

    var url = new URL(_constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_CITY_BY_LOCATION + '?');
    var params = new URLSearchParams(url.search.slice(1));
    params.append('lat', lat); //no support for IE browser

    params.append('lon', long);
    var finalUrl = url + params; // let finalUrl = constants.BASE_API_URL + constants.apiPoint + urls.GET_CITY_BY_LOCATION + '?lat='+lat+'&lon='+long;

    return fetch(finalUrl, {
      method: 'GET',
      headers: customizedHeaders
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LOCATION_DATA_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_LOCATION_DATA_FAILURE,
        errorMessage: error
      });
    });
  };
}
;
function getRestaurentData(data) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DATA,
      isReset: data.isForceRefreshList ? true : false
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]); // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
    // if(data.searchword){
    //     url += '&q='+data.searchword;
    // }
    // if(data.count){
    //     url += '&count='+data.count;
    // }
    // if(data.lat){
    //     url += '&lat='+data.lat;
    // }
    // if(data.lon){
    //     url += '&lon='+data.lon;
    // }
    // if(data.start){
    //     url += '&start='+data.start;
    // }
    // if(data.radius){
    //     url += '&radius='+data.radius;
    // }
    // if(data.sort){
    //     url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
    // } else {
    //     url += '&sort=real_distance';
    // }
    // if(data.order){
    //     url += data.order ? '&order='+data.order : '&order=desc';
    // } else {
    //     url += '&order=desc';
    // }


    var params = {
      entity_id: data.entity_id,
      entity_type: data.entity_type,
      q: data.searchword ? data.searchword : '',
      count: data.count,
      lat: data.lat,
      lon: data.lon,
      start: data.start,
      radius: data.radius ? data.radius : '',
      sort: data.sort ? data.sort : 'real_distance',
      order: data.order ? data.order : 'desc'
    };
    var queryParams = Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
    var finalUrl = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_RESTAURENTS_BY_LOCATION + '?' + queryParams;
    return fetch(finalUrl, {
      method: 'GET',
      headers: customizedHeaders
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DATA_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DATA_FAILURE,
        errorMessage: error
      });
    });
  };
}
;
function searchRestaurentData(data) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_SEARCH_DATA
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]); // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENTS_BY_LOCATION + '?entity_id='+data.entity_id+'&entity_type='+data.entity_type;
    // if(data.searchword){
    //     url += '&q='+data.searchword;
    // }
    // if(data.count){
    //     url += '&count='+data.count;
    // }
    // if(data.lat){
    //     url += '&lat='+data.lat;
    // }
    // if(data.lon){
    //     url += '&lon='+data.lon;
    // }
    // if(data.start){
    //     url += '&start='+data.start;
    // }
    // if(data.radius){
    //     url += '&radius='+data.radius;
    // }
    // if(data.sort){
    //     url += data.sort ? '&sort='+data.sort : '&sort=real_distance';
    // } else {
    //     url += '&sort=real_distance';
    // }
    // if(data.order){
    //     url += data.order ? '&order='+data.order : '&order=desc';
    // } else {
    //     url += '&order=desc';
    // }


    var params = {
      entity_id: data.entity_id,
      entity_type: data.entity_type,
      q: data.searchword ? data.searchword : '',
      count: data.count,
      lat: data.lat,
      lon: data.lon,
      start: data.start,
      radius: data.radius ? data.radius : '',
      sort: data.sort ? data.sort : 'real_distance',
      order: data.order ? data.order : 'desc'
    };
    var queryParams = Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
    var finalUrl = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_RESTAURENTS_BY_LOCATION + '?' + queryParams;
    return fetch(finalUrl, {
      method: 'GET',
      headers: customizedHeaders
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DATA_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DATA_FAILURE,
        errorMessage: error
      });
    });
  };
}

/***/ }),

/***/ "./src/components/Home.js":
/*!********************************!*\
  !*** ./src/components/Home.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router-redux */ "./node_modules/react-router-redux/lib/index.js");
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_router_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-waypoint */ "./node_modules/react-waypoint/es/index.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils */ "./src/utils.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _presentations_Header__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../presentations/Header */ "./src/presentations/Header.js");
/* harmony import */ var _actions_homeActions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../actions/homeActions */ "./src/actions/homeActions.js");
/* harmony import */ var _presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../presentations/SvgLoading */ "./src/presentations/SvgLoading.js");
/* harmony import */ var _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../assets/images/ic-star-full.svg */ "./src/assets/images/ic-star-full.svg");
/* harmony import */ var _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _assets_images_food_png__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../assets/images/food.png */ "./src/assets/images/food.png");








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }



 // import { Link } from 'react-router';






 // import SvgIcon from '../presentations/SvgIcon';





var Home = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Home, _Component);

  var _super = _createSuper(Home);

  function Home(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Home);

    _this = _super.call(this, props);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "resizeList", function () {
      _this.setState({
        toggleresize: !_this.state.toggleresize,
        windowHeight: window.innerHeight
      });

      console.log('resized');
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "renderListHeight", function () {
      return _this.state.windowHeight - 150 + 'px';
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "getLocation", function (type) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(_this.showPosition, _this.locationFetchFail);

        if (type) {
          _this.setState({
            isForceRefreshList: type && type == 'force'
          });
        }
      } else {
        alert('Geolocation is not supported by this browser');
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "locationFetchFail", function (data) {
      alert(data.code === 1 ? 'Error: ' + data.message + ', Please allow browser to detect location' : 'Error: ' + data.message + '');
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "makeApiCalls", function (type, data) {
      if (type) {
        switch (type) {
          case 'GET_LOCATION_DATA':
            {
              if (data) return _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_15__["getLocationData"])(data.latitude, data.longitude));
            }

          case 'GET_RESTAURENTS_DATA':
            {
              if (data) return _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_15__["getRestaurentData"])(data));
            }

          case 'SEARCH_RESTAURENTS_DATA':
            {
              if (data) return _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_15__["searchRestaurentData"])(data));
            }

          default:
            {
              return null;
            }
        }
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "showPosition", function (position) {
      var data = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };

      _this.makeApiCalls('GET_LOCATION_DATA', data);
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "getEndOfListMarkup", function () {
      if (_this.state.loadOnScroll && !_this.props.homeApis.searchingRestaurentsFailure && !_this.props.homeApis.searchingRestaurents) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_waypoint__WEBPACK_IMPORTED_MODULE_10__["Waypoint"], {
          onEnter: function onEnter() {
            return _this.fetchMoreCards();
          }
        });
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "fetchMoreCards", function () {
      var totalItemCount = _this.props.homeApis.searchRestaurentsResultData.results_found;
      var curentNumber = _this.props.homeApis.searchRestaurentsResultData && _this.props.homeApis.searchRestaurentsResultData.restaurants && _this.props.homeApis.searchRestaurentsResultData.restaurants.length ? _this.props.homeApis.searchRestaurentsResultData.restaurants.length : 0;

      if (!_this.props.homeApis.searchingRestaurentsFailure && (!totalItemCount || totalItemCount > _this.props.homeApis.searchRestaurentsResultData.restaurants.length)) {
        var tempState = Object.assign({}, _this.state);
        tempState.searchData.results_found = totalItemCount;
        tempState.searchData.start = curentNumber;
        if (tempState.searchData.isForceRefreshList) tempState.searchData.isForceRefreshList = false;

        _this.setState(tempState);

        _this.makeApiCalls('GET_RESTAURENTS_DATA', tempState.searchData);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleThumbnailLoadError", function (event) {
      event.target.src = _assets_images_food_png__WEBPACK_IMPORTED_MODULE_18__["default"];
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "goToDetailPage", function (id) {
      _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/restaurant/' + id));
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "listPaneDidMount", function (node) {
      if (node) {
        node.addEventListener('scroll', _this.handleListScroll);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleListScroll", function (event) {
      var node = event.target;
      var bottom = node.scrollHeight - node.scrollTop === node.clientHeight;

      if (bottom) {
        // console.log('BOTTOM REACHED:', bottom);
        _this.fetchMoreCards();
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "searchByKeyword", function (event) {
      if (event && event.target) {
        var searchText = event.target.value;
        var searchData = _this.state.searchData;
        var tempState = Object.assign({}, _this.state);
        tempState.searchKey = searchText;
        tempState.searchData.searchword = searchText;
        tempState.searchData.start = 0;

        _this.setState({
          searchKey: searchText
        });

        _this.makeApiCalls('SEARCH_RESTAURENTS_DATA', tempState.searchData);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "rateSort", function () {
      var tempState = Object.assign({}, _this.state);
      var currentState = tempState.isRateSorted;
      tempState.searchData.start = 0;

      if (currentState) {
        tempState.searchData.sort = 'real_distance';
      } else {
        tempState.searchData.sort = 'rating';
      }

      tempState.isRateSorted = !tempState.isRateSorted;

      _this.setState(tempState);

      _this.makeApiCalls('SEARCH_RESTAURENTS_DATA', tempState.searchData);
    });

    _this.state = {
      name: 'pavan',
      locationData: {},
      restaurentsData: {},
      searchKey: null,
      loadOnScroll: true,
      toggleresize: false,
      isForceRefreshList: false,
      isRateSorted: false,
      windowHeight: window.innerHeight,
      possibleSortValues: [{
        id: 0,
        value: 'cost',
        displayName: 'Cost'
      }, {
        id: 1,
        value: 'rating',
        displayName: 'Rating'
      }, {
        id: 2,
        value: 'real_distance',
        displayName: 'Distance'
      }],
      possiblOrderValues: [{
        id: 0,
        value: 'asc',
        displayName: 'Ascending'
      }, {
        id: 1,
        value: 'desc',
        displayName: 'Descending'
      }],
      searchData: {
        entity_id: null,
        entity_type: null,
        searchword: null,
        count: _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_Limit,
        lat: null,
        lon: null,
        radius: null,
        sort: null,
        order: null,
        start: 0,
        results_found: null
      },
      makeApiCalls: _this.makeApiCalls.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this))
    }; // this.showPosition = this.showPosition.bind(this);
    // this.getEndOfListMarkup = this.getEndOfListMarkup.bind(this);
    // this.fetchMoreCards = debounce(this.fetchMoreCards, 500, this);
    // this.resizeList = debounce(this.resizeList,1000,this);
    // this.listPaneDidMount = this.listPaneDidMount.bind(this);
    // this.handleListScroll = this.handleListScroll.bind(this);
    // this.rateSort = this.rateSort.bind(this);
    // this.goToDetailPage = this.goToDetailPage.bind(this);

    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Home, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getLocation();
      window.addEventListener('resize', this.resizeList);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      window.removeEventListener('resize', this.resizeList);
    } // componentWillReceiveProps(nextProps){
    //     if(this.props.homeApis.fetchingLocationData && nextProps.homeApis.fetchedLocationDataSuccess && nextProps.homeApis.fetchedLocationData){
    //         this.setState({locationData : nextProps.homeApis.fetchedLocationData});
    //         if(nextProps.homeApis.fetchedLocationData.location){
    //             let reqData = nextProps.homeApis.fetchedLocationData.location;
    //             let searchData = {
    //                 entity_id: reqData.entity_id,
    //                 entity_type: reqData.entity_type,
    //                 searchword: this.state.searchKey,
    //                 count: constants.list_Limit,
    //                 lat: reqData.latitude,
    //                 lon: reqData.longitude,
    //                 radius: null,
    //                 sort: null,
    //                 order: null,
    //                 start: 0,
    //                 results_found: null
    //             }
    //             this.setState({searchData: searchData});
    //             if(this.state.isForceRefreshList){
    //                 searchData.isForceRefreshList =  this.state.isForceRefreshList;
    //                 this.makeApiCalls('GET_RESTAURENTS_DATA',searchData);
    //                 this.setState({isForceRefreshList: false});
    //             }
    //         }
    //     }
    //     if(nextProps.homeApis.searchRestaurentsResultData && nextProps.homeApis.searchingRestaurentsSuccess && this.props.homeApis.searchingRestaurents){
    //         this.setState({restaurentsData: nextProps.homeApis.searchRestaurentsResultData, loadOnScroll: nextProps.homeApis.searchRestaurentsResultData.restaurants && nextProps.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
    //     }
    // }

  }, {
    key: "getSnapshotBeforeUpdate",
    value: function getSnapshotBeforeUpdate(prevProps, prevState) {
      // for componentWillUpdate
      return null;
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps, prevState, snapshot) {}
  }, {
    key: "renderRestaurents",
    value: function renderRestaurents(item, id) {
      var _this2 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
        key: id,
        onClick: function onClick(event) {
          return _this2.goToDetailPage(item.restaurant.id);
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "imgHeader"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          paddingLeft: '0.5em',
          width: '30%'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default.a, {
        height: 75,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        className: "restaurentImg",
        width: "75",
        alt: 'Restaurent Logo',
        src: item.restaurant.thumb,
        onError: this.handleThumbnailLoadError
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "restAddr",
        style: {
          padding: '0px 10px',
          width: '45%',
          'maxHeight': '-webkit-fill-available',
          overflow: 'hidden'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, item.restaurant.location.address)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          paddingRight: '0.5em',
          width: '25%'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h4", {
        style: {
          maxWidth: '150px',
          textOverflow: 'ellipsis',
          overflow: 'hidden',
          whiteSpace: 'nowrap'
        }
      }, item.restaurant.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "rating",
        style: {
          textOverflow: 'ellipsis',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
          display: 'flex'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default.a, {
        height: 20,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        src: _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_17___default.a,
        width: "12px"
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        style: {
          paddingLeft: '5px'
        }
      }, item.restaurant.user_rating.aggregate_rating ? item.restaurant.user_rating.aggregate_rating : '0', "\xA0", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        style: {
          color: '#E23744'
        }
      }, "(Votes: ", item.restaurant.user_rating.votes, ")"))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", {
        style: {
          width: '100%',
          border: 'none',
          height: '0.5px',
          background: '#9a9a9a'
        }
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          display: 'flex',
          justifyContent: 'space-between',
          width: '100%'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, "Cost for two : ", item.restaurant.average_cost_for_two), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          textOverflow: 'ellipsis',
          overflow: 'hidden',
          maxWidth: '200px',
          whiteSpace: 'nowrap'
        }
      }, "Hours: ", item.restaurant.timings)));
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "overlay",
        style: {
          display: this.props.homeApis.fetchingLocationData || this.props.homeApis.searchingRestaurents ? "block" : "none"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "loading"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_16__["default"], null))), this.state.locationData && this.state.locationData.location ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, this.state.locationData.location ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Header__WEBPACK_IMPORTED_MODULE_14__["default"], {
        showLogo: true,
        showLocationFinder: true,
        showSearchRestaurent: true,
        findLocation: function findLocation() {
          return _this3.getLocation('force');
        },
        searchRestaurent: this.searchByKeyword,
        locationName: this.state.locationData.location.title
      }) : null, this.state.restaurentsData && this.state.restaurentsData.restaurants && this.state.restaurentsData.restaurants.length > 0 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "mainContainer"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          width: '100%',
          display: 'flex',
          justifyContent: 'flex-end',
          cursor: 'pointer'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        style: {
          paddingRight: '1em'
        },
        onClick: this.rateSort
      }, "Sort By: ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        style: {
          color: this.state.isRateSorted ? '#099e44' : '#000'
        }
      }, "Rating (High - Low)"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        ref: this.listPaneDidMount,
        className: "rest-tiles",
        style: {
          height: this.renderListHeight(),
          overflow: 'scroll'
        }
      }, this.state.restaurentsData.restaurants.map(function (item, id) {
        return _this3.renderRestaurents(item, id);
      }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, "No Restaurants found...!"), this.props.homeApis.fetchedLocationDataSuccess && !this.state.restaurentsData.restaurants ? this.getEndOfListMarkup() : null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: "startError"
      }, "Please enable location to populate results"));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      // for componentReceiveProps
      // console.log(props);
      if (props.homeApis.fetchedLocationDataSuccess && props.homeApis.fetchedLocationData) {
        //props.homeApis.fetchingLocationData &&
        // this.setState({locationData : props.homeApis.fetchedLocationData});
        state.locationData = props.homeApis.fetchedLocationData;

        if (props.homeApis.fetchedLocationData.location) {
          var reqData = props.homeApis.fetchedLocationData.location;
          var searchData = {
            entity_id: reqData.entity_id,
            entity_type: reqData.entity_type,
            searchword: state.searchKey,
            count: _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_Limit,
            lat: reqData.latitude,
            lon: reqData.longitude,
            radius: null,
            sort: null,
            order: null,
            start: 0,
            results_found: null
          }; // this.setState({searchData: searchData});

          state.searchData = searchData;

          if (state.isForceRefreshList) {
            searchData.isForceRefreshList = state.isForceRefreshList;
            state.makeApiCalls('GET_RESTAURENTS_DATA', searchData); // this.setState({isForceRefreshList: false});

            state.isForceRefreshList = false;
          }
        }
      }

      if (props.homeApis.searchRestaurentsResultData && props.homeApis.searchingRestaurentsSuccess) {
        // && props.homeApis.searchingRestaurents
        // this.setState({restaurentsData: props.homeApis.searchRestaurentsResultData, loadOnScroll: props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false});
        state.restaurentsData = props.homeApis.searchRestaurentsResultData;
        state.loadOnScroll = props.homeApis.searchRestaurentsResultData.restaurants && props.homeApis.searchRestaurentsResultData.restaurants.length > 0 ? true : false;
      }

      return state;
    }
  }]);

  return Home;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

function mapStateToProps(state) {
  return {
    homeApis: state.homeApis
  };
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(mapStateToProps)(Home));

/***/ })

}]);