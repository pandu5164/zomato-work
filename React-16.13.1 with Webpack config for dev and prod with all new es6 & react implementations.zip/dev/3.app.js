(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ "./src/actions/restaurantDetailActions.js":
/*!************************************************!*\
  !*** ./src/actions/restaurantDetailActions.js ***!
  \************************************************/
/*! exports provided: getRestaurantDetails, getRestaurantDetail, getRestaurantReviews */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRestaurantDetails", function() { return getRestaurantDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRestaurantDetail", function() { return getRestaurantDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRestaurantReviews", function() { return getRestaurantReviews; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ "./src/actions/index.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _urls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../urls */ "./src/urls.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils */ "./src/utils.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





function getRestaurantDetails(data) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]);

    var url = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_RESTAURENT_DETAIL + '?';
    var params = {
      res_id: data
    };
    var queryParams = Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
    var finalUrl = url + queryParams;
    return Object(_utils__WEBPACK_IMPORTED_MODULE_4__["fetch_retry"])(function () {
      return fetch(finalUrl, {
        method: 'GET',
        headers: customizedHeaders
      }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
        dispatch({
          type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL_SUCCESS,
          data: response
        });
      }).catch(function (error) {
        dispatch({
          type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL_FAILURE,
          errorMessage: error
        });
      });
    });
  };
}
function getRestaurantDetail(data) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]);

    var url = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_RESTAURENT_DETAIL + '?';
    var params = {
      res_id: data
    };
    var queryParams = Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
    var finalUrl = url + queryParams;
    return fetch(finalUrl, {
      method: 'GET',
      headers: customizedHeaders
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_DETAIL_FAILURE,
        errorMessage: error
      });
    });
  };
}
;
function getRestaurantReviews(data) {
  return function (dispatch, getState) {
    // const state = getState();
    dispatch({
      type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_REVIEW
    });

    var customizedHeaders = _objectSpread({}, _utils__WEBPACK_IMPORTED_MODULE_4__["commonHeaders"]); // let url = constants.BASE_API_URL + constants.apiPoint + urls.GET_RESTAURENT_REVIEW + '?res_id='+data.id;
    // if(data.start){
    //     url += '&start='+data.start;
    // }
    // if(data.count){
    //     url += '&count='+data.count;
    // }


    var url = _constants__WEBPACK_IMPORTED_MODULE_2__["default"].BASE_API_URL + _constants__WEBPACK_IMPORTED_MODULE_2__["default"].apiPoint + _urls__WEBPACK_IMPORTED_MODULE_3__["default"].GET_RESTAURENT_REVIEW + '?';
    var finalUrl = url + new URLSearchParams({
      res_id: data.id,
      start: data.start,
      count: data.count
    });
    return fetch(finalUrl, {
      method: 'GET',
      headers: customizedHeaders
    }).then(_utils__WEBPACK_IMPORTED_MODULE_4__["checkHttpStatus"]).then(function (response) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_REVIEW_SUCCESS,
        data: response
      });
    }).catch(function (error) {
      dispatch({
        type: _index__WEBPACK_IMPORTED_MODULE_1__["default"].GET_RESTAURENT_REVIEW_FAILURE,
        errorMessage: error
      });
    });
  };
}
;

/***/ }),

/***/ "./src/components/RestaurantDetail.js":
/*!********************************************!*\
  !*** ./src/components/RestaurantDetail.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _presentations_Header__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../presentations/Header */ "./src/presentations/Header.js");
/* harmony import */ var _presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../presentations/SvgLoading */ "./src/presentations/SvgLoading.js");
/* harmony import */ var _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../assets/images/ic-star-full.svg */ "./src/assets/images/ic-star-full.svg");
/* harmony import */ var _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_food_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../assets/images/food.png */ "./src/assets/images/food.png");
/* harmony import */ var _actions_restaurantDetailActions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../actions/restaurantDetailActions */ "./src/actions/restaurantDetailActions.js");








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }


 // import { push } from 'react-router-redux';
// import { Link } from 'react-router';
// import { Waypoint } from 'react-waypoint';

 // import { debounce } from '../utils';


 // import SvgIcon from '../presentations/SvgIcon';






var RestaurantDetail = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(RestaurantDetail, _Component);

  var _super = _createSuper(RestaurantDetail);

  function RestaurantDetail(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, RestaurantDetail);

    _this = _super.call(this, props);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "getReviews", function (data) {
      _this.props.dispatch(Object(_actions_restaurantDetailActions__WEBPACK_IMPORTED_MODULE_15__["getRestaurantReviews"])(data));

      _this.setState({
        loadReviews: false
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleThumbnailLoadError", function (event) {
      event.target.src = _assets_images_food_png__WEBPACK_IMPORTED_MODULE_14__["default"];
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "renderHeight", function () {
      return window.innerHeight - 50 + 'px';
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "setFacet", function (itm, id) {
      // console.log(itm);
      var tempState = Object.assign({}, _this.state);

      if (tempState.facets && tempState.facets.length) {
        tempState.facets.forEach(function (itm) {
          itm.isSelected = false;
        });
      }

      var selectedItem = tempState.facets.filter(function (itm, idx) {
        return idx == id;
      });

      if (selectedItem.length) {
        selectedItem[0].isSelected = true;
        tempState.selectedView = selectedItem[0].value;

        _this.setState(tempState);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "listPaneDidMount", function (node) {
      if (node) {
        node.addEventListener('scroll', _this.handleListScroll);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleListScroll", function (event) {
      var node = event.target;
      var bottom = node.scrollHeight - node.scrollTop === node.clientHeight;

      if (bottom) {
        // console.log('BOTTOM REACHED:', bottom);
        _this.fetchMoreReviews();
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "fetchMoreReviews", function () {
      var totalItemCount = _this.props.restaurentDetailApis.reviewData.reviews_count;
      var curentNumber = _this.props.restaurentDetailApis.reviewData && _this.props.restaurentDetailApis.reviewData.user_reviews && _this.props.restaurentDetailApis.reviewData.user_reviews.length ? _this.props.restaurentDetailApis.reviewData.user_reviews.length : 0;

      if (!_this.props.restaurentDetailApis.gettingRestaurentReviewsFailure && (!totalItemCount || totalItemCount > _this.props.restaurentDetailApis.reviewData.user_reviews.length)) {
        _this.setState({
          loadReviews: true
        });

        var data = {
          id: _this.state.rest_id,
          start: curentNumber,
          count: _constants__WEBPACK_IMPORTED_MODULE_10__["default"].review_Limit,
          total: totalItemCount
        };

        _this.getReviews(data); // this.props.dispatch(getRestaurantReviews({ id: this.state.rest_id, start: curentNumber, count: constants.review_Limit, total: totalItemCount}));

      }
    });

    _this.state = {
      name: 'welcome to product detail page',
      restaurentData: {},
      rest_id: null,
      facets: [{
        id: 0,
        value: 'Highlights',
        isSelected: true
      }, {
        id: 1,
        value: 'Reviews',
        isSelected: false
      }],
      selectedView: 'Highlights',
      getReviews: _this.getReviews.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this)),
      loadReviews: false
    }; // this.renderReviews = this.renderReviews.bind(this);
    // this.setFacet = this.setFacet.bind(this);
    // this.listPaneDidMount = this.listPaneDidMount.bind(this);
    // this.handleListScroll = this.handleListScroll.bind(this);
    // this.fetchMoreReviews = this.fetchMoreReviews.bind(this);

    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(RestaurantDetail, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (this.props.params.id) {
        // console.log(this.props.params.id);
        this.setState({
          rest_id: this.props.params.id,
          loadReviews: true
        });
        this.props.dispatch(Object(_actions_restaurantDetailActions__WEBPACK_IMPORTED_MODULE_15__["getRestaurantDetails"])(this.props.params.id));
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      console.log('Detail page unmounted');
    } // componentWillReceiveProps(nextProps) {
    //     if (this.props.restaurentDetailApis.gettingRestaurentDetails && nextProps.restaurentDetailApis.gettingRestaurentDetailsSuccess && nextProps.restaurentDetailApis.restaurentData) {
    //         this.setState({ restaurentData: nextProps.restaurentDetailApis.restaurentData });
    //         this.props.dispatch(getRestaurantReviews({ id: this.state.rest_id, start: 0, count: constants.review_Limit }))
    //     }
    // }

  }, {
    key: "getSnapshotBeforeUpdate",
    value: function getSnapshotBeforeUpdate(prevProps, prevState) {
      // for componentWillUpdate
      return null;
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps, prevState, snapshot) {}
  }, {
    key: "renderReviews",
    value: function renderReviews(item, id) {
      // if(item.review.review_text)
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
        key: id
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, item.review.review_text ? item.review.review_text : null));
    }
  }, {
    key: "renderFacetHeight",
    value: function renderFacetHeight() {
      //if(document.getElementsByClassName('facets')[0]){
      if (this.refs.facets) {
        var position = this.refs.facets.getBoundingClientRect();
        var finalValue = window.innerHeight - (position.top + position.height) - 50;
        return finalValue + 'px';
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "overlay",
        style: {
          display: this.props.restaurentDetailApis.gettingRestaurentDetails || this.props.restaurentDetailApis.gettingRestaurentReviews ? "block" : "none"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "loading"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_12__["default"], null))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Header__WEBPACK_IMPORTED_MODULE_11__["default"], {
        showLogo: true,
        showLocationFinder: false,
        showSearchRestaurent: false,
        findLocation: function findLocation() {},
        searchRestaurent: false,
        locationName: false
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "mainContainer",
        style: {
          height: this.renderHeight()
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "restaurentMainInfo"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "restImage"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_9___default.a, {
        height: 100,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        className: "restaurentImg",
        width: "100",
        alt: 'Restaurent Logo',
        src: this.state.restaurentData.thumb,
        onError: this.handleThumbnailLoadError
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "nameCusine"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h4", null, this.state.restaurentData.name ? this.state.restaurentData.name : 'Restaurant name not available')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "flex-start-center-align-styled"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h5", null, "Cuisines:"), " "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "textSpacingBtwn"
      }, this.state.restaurentData.cuisines && this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? this.state.restaurentData.cuisines : '-', " ", this.state.restaurentData.cuisines && this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? '-' : null, " ", this.state.restaurentData.establishment && this.state.restaurentData.establishment.length ? this.state.restaurentData.establishment.join(', ') : 'No Specail establishments available')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "flex-start-center-align-styled"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h5", null, "Location:")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "textSpacingBtwn"
      }, this.state.restaurentData.location ? this.state.restaurentData.location.locality : '-')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "flex-start-center-align-styled"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h5", null, "Timings:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "textSpacingBtwn"
      }, this.state.restaurentData.timings ? this.state.restaurentData.timings : 'Opens 24hrs. in a day'))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "nameCusine ratingInfo"
      }, this.state.restaurentData.user_rating && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "flex-start-center-align-styled"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h5", null, "Rating:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "textSpacingBtwn"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_9___default.a, {
        height: 20,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        src: _assets_images_ic_star_full_svg__WEBPACK_IMPORTED_MODULE_13___default.a,
        width: "12px"
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, this.state.restaurentData.user_rating.aggregate_rating))), this.state.restaurentData.phone_numbers && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "flex-start-center-align-styled"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h5", null, "Call us:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "textSpacingBtwn"
      }, this.state.restaurentData.phone_numbers ? this.state.restaurentData.phone_numbers : 'Number not available')))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "facets",
        ref: "facets"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        className: "facetList"
      }, this.state.facets.map(function (itm, idx) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
          key: idx,
          onClick: function onClick(event) {
            return _this2.setFacet(itm, idx);
          },
          className: itm.isSelected ? "facet selected" : "facet notSelected"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          className: itm.isSelected ? "facetValue selected" : "facetValue notSelected"
        }, itm.value));
      })))), this.state.selectedView == 'Highlights' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, this.state.selectedView == 'Highlights' && this.state.restaurentData.highlights && this.state.restaurentData.highlights.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          paddingLeft: '40px',
          height: this.renderFacetHeight(),
          overflow: 'scroll'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        style: {
          listStyleType: 'decimal',
          padding: '0',
          lineHeight: '2em'
        }
      }, this.state.restaurentData.highlights.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
          key: id
        }, item);
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "nameCusine"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h4", null, "Average Cost: "), this.state.restaurentData.average_cost_for_two, " for two people (approx.)")) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "restaurentMainInfo"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          padding: '2%'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, "No Highlights Available...!")))) : null, this.state.selectedView == 'Reviews' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, this.state.selectedView == 'Reviews' && this.props.restaurentDetailApis.reviewData && this.props.restaurentDetailApis.reviewData.user_reviews && this.props.restaurentDetailApis.reviewData.user_reviews.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "reviewArea"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        ref: this.listPaneDidMount,
        style: {
          height: this.renderFacetHeight(),
          overflow: 'scroll',
          listStyleType: 'decimal',
          lineHeight: '1em'
        }
      }, this.props.restaurentDetailApis.reviewData.user_reviews.map(function (item, id) {
        return _this2.renderReviews(item, id);
      }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "restaurentMainInfo"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        style: {
          padding: '2%'
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, "No Reviews Available...!")))) : null));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(nextProps, prevState) {
      if (nextProps.restaurentDetailApis.gettingRestaurentDetailsSuccess && nextProps.restaurentDetailApis.restaurentData) {
        //this.props.restaurentDetailApis.gettingRestaurentDetails &&
        // this.setState({ restaurentData: nextProps.restaurentDetailApis.restaurentData });
        prevState.restaurentData = nextProps.restaurentDetailApis.restaurentData; // nextProps.dispatch(getRestaurantReviews({ id: prevState.rest_id, start: 0, count: constants.review_Limit }))

        if (prevState.loadReviews) {
          var data = {
            id: prevState.rest_id,
            start: 0,
            count: _constants__WEBPACK_IMPORTED_MODULE_10__["default"].review_Limit
          };
          prevState.getReviews(data);
        }
      }

      return prevState;
    }
  }]);

  return RestaurantDetail;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

function mapStateToProps(state) {
  return {
    homeApis: state.homeApis,
    restaurentDetailApis: state.restaurentDetailApis
  };
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(mapStateToProps)(RestaurantDetail));

/***/ })

}]);