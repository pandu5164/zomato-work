export default {
    GET_CITY_BY_LOCATION: '/geocode',
    GET_RESTAURENTS_BY_LOCATION: '/search',
    GET_RESTAURENT_DETAIL: '/restaurant',
    GET_RESTAURENT_REVIEW: '/reviews'
}